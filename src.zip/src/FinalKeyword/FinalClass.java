package FinalKeyword;

public class FinalClass {

	public static void main(String[] args) {
		
	}

}
