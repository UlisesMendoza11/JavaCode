package FinalKeyword;

class Department {
	int deptId = 10011;
	String name = "Department";
	
	final void report() {
		System.out.println("Department Id: " + deptId);
		System.out.println("Department Name: " + name);
	}
}

class Product extends Department
{
	int productID = 10011;
	String pname = "Laptop";
	
	
	void report() {
		System.out.println("Product Id: " + productID);
		System.out.println("Product Name: " + pname);
	}
}


public class FinalMethod {

	public static void main(String[] args) {
		Product p = new Product();
		p.report();
	}

}
