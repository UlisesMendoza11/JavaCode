package FinalKeyword;

class Employee
{
	final int empId = 10011;
	String name = "John";
}

public class FinalVariable {

	public static void main(String[] args) {
		Employee e = new Employee();
		System.out.println("Employee Id: " + e.empId);
		System.out.println("Employee Name: " + e.name);
		
		e.name = "Jackson";
		System.out.println("Updated Employee Name: " + e.name);
	}

}
