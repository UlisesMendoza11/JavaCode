package String;
import java.util.Scanner;
public class AlternativeCode {

	public static String isAlternating(String str) {
		for(int i = 0; i < str.length()-1; i++) {
			char c1 = str.charAt(i);
			char c2 = str.charAt(i+1);
			if() {
				return "No";
			}
		}
		return "Yes";
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter string: ");
		String str = sc.nextLine();
		
		System.out.println("Is " + str + " alternating: " + isAlternating(str));
	}

}
