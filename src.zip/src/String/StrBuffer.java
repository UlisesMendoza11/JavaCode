package String;

public class StrBuffer {

	public static void main(String[] args) {
		StringBuffer s = new StringBuffer("Hello");
		s.insert(2,  "Java");
		System.out.println(s);
		
		s.delete(6, 11);
		System.out.println(s);
		
		s.reverse(); System.out.println(s);
		s.replace(6, 11, "Java "); System.out.println(s);
		
	}

}
