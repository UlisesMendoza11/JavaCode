package String;

public class Immutable {

	public static void main(String[] args) {
		String s = "Sachin"; // immutable
		s = s.concat("tendulkar");	
		System.out.println(s);
	}

}
