package String;

public class StringConcat {

	public static void main(String[] args) {
		String s1 = "java string";
		
		s1.concat("is immutable");
		
		System.out.println(s1);
		
		s1 = s1.concat("is immutable so assign it explicitly");
		
		System.out.println(s1);
		
		String str1 = "Hello";
		String str2 = " World";
		String str3 = " good Morning";
		
		String str4 = str1.concat(str2);
		String str5 = str1.concat(str3);
		System.out.println(str4);
		System.out.println(str5);
	}

}
