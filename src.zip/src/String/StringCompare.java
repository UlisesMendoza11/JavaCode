package String;

public class StringCompare {

	public static void main(String[] args) {
		String str1 = "Hello";
		String str2 = "Hello";
		String str3 = "hello";
		
		String s1 = "Sachin";
		String s2 = "Sachin";
		String s3 = new String("Sachin");
		String s4 = "Saurav";
		
		System.out.println(str1.equals(str2));
		System.out.println(str1.equals(str3));
		
		System.out.println("s1 == s2: " + s1.equals(s2));
		System.out.println("s1 == s3: " + s1.equals(s3));
		System.out.println("s1 == s4: " + s1.equals(s4));
		
	}

}
