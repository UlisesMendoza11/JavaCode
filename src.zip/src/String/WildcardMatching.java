package String;

import java.util.Scanner;

public class WildcardMatching {

	public static String isMatched(String str1, String str2) {
		for(int i = 0; i < str1.length(); i++) {
			char c1 = str1.charAt(i);
			char c2 = str2.charAt(i);
			if(c1 == '?' || c2 == '?') {
				continue;
			}
			if(c1 != c2) {
				return "No";
			}
		}
		return "Yes";
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter first string:");
		String str1 = sc.nextLine();
		String str2;
		while(true) {
			try { 
				System.out.print("Enter second string:");
				str2 = sc.nextLine();
				if (str2.length() == str1.length()) {
					break;
				}
				else {
					throw new NotSameLengthException("Strings not same length, enter another string to match length of first string.");
				}
			} catch (NotSameLengthException e) {
				System.out.println(e.getMessage());
			}
		}
		
		System.out.println(isMatched(str1, str2));
		
		sc.close();
	}

}
