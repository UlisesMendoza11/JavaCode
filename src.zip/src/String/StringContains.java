package String;

public class StringContains {

	public static void main(String[] args) {
		
		String s = "In Java String is an Object and its an Immutable Object";
		System.out.println(s.contains("Java String"));
		System.out.println(s.contains("Java String1234"));
		System.out.println(s.contains("Immutable"));
	}

}
