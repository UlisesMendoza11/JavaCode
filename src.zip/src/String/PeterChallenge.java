package String;

import java.util.Scanner;

public class PeterChallenge {

	public static String didPeterWin(String str) {
		int count = 0;
		for(int i = 0; i < str.length(); i++) {
			int temp = Integer.parseInt(str.substring(i, i+1));
			if(temp == 1) {
				count++;
			}
			if(count == 11) {
				return "Win";
			}
		}
		return "Lose";
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter first string:");
		String str1 = sc.nextLine();
		
		
		System.out.println();
		
		sc.close();
	}

}
