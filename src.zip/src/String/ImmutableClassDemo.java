package String;

public class ImmutableClassDemo {

	private final int intValue;
	private final String stringValue;
	
	ImmutableClassDemo(int intValue, String stringValue) {
		this.intValue = intValue;
		this.stringValue = stringValue;
	}
	
	public int getIntValue() {
		return this.intValue;
	}
	
	public String getStringValue() {
		return this.stringValue;
	}
	
	public static void main(String[] args) {
		ImmutableClassDemo obj = new ImmutableClassDemo(10011, "Hello");
		System.out.println(obj.getIntValue());
		System.out.println(obj.getStringValue());
	}

}
