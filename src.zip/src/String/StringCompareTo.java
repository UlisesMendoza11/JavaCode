package String;

public class StringCompareTo {

	public static void main(String[] args) {
		String s1 = "World";
		String s2 = "World";
		String s3 = "Hello";
		String s4 = "john";
		
		String str1 = new String("JAVA STRING DEMO");
		
		String str2 = new String("java string demo");
		
		String str3 = new String("JAVA");
		
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s3));
		System.out.println(s1.compareTo(s4));
		
		System.out.println(str1.compareTo(str2));
		System.out.println(str1.compareTo(str3));
}

}
