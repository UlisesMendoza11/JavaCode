package String;

public class NonEmptyString {

	public static void main(String[] args) {
		String s = "Hello world... good evening";
		
		System.out.println(s.length());
		System.out.println(s.charAt(6));
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		System.out.println("sub string from 5 to 10: " + s.substring(5,10));
		System.out.println(s.replace("world", "EveryOne"));
		System.out.println(s.indexOf("good"));
		for(int i = 0; i < s.length(); i++) {
			System.out.println("Index is: " + i + " = " + s.charAt(i));
		}
	}

}
