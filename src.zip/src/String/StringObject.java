package String;

public class StringObject {

	public static void main(String[] args) {
		String s1 = "Java"; // will be stored in String constant pool
		
		char ch[] = {'S', 't', 'r', 'i', 'n', 'g'};
		
		String s2 = new String(ch); // new keyword string will be stored in heap
		
		String s3 = new String("String demo");
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
	}

}
