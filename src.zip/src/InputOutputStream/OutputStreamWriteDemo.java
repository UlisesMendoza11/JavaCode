package InputOutputStream;
import java.io.*;
public class OutputStreamWriteDemo {

	public static void main(String[] args) throws Exception {
		OutputStream ops = new FileOutputStream("");
		Writer w = new OutputStreamWriter(ops);
		w.write("Hello World ! Good Evening...");
		System.out.println("Success");
		w.close();
		
	}

}
