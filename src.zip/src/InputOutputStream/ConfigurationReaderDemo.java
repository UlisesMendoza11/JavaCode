package InputOutputStream;
import java.io.*;
public class ConfigurationReaderDemo {

	public static void main(String[] args) {
		String fileName = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName));
			String line;
			while((line = br.readLine()) != null) {
				System.out.println(line);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
