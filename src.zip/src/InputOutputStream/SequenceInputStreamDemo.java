package InputOutputStream;
import java.io.*;
public class SequenceInputStreamDemo {

	public static void main(String[] args) throws Exception {
		FileInputStream f1 = new FileInputStream("");
		FileInputStream f2 = new FileInputStream("");
		FileOutputStream fout = new FileOutputStream("");
		
		SequenceInputStream sin = new SequenceInputStream(f1, f2);
		int i;
		while((i = sin.read()) != -1) {
			fout.write(i);
		}
		
		int j;
		
		while((j = sin.read()) != -1) {
			System.out.println((char) j);
		}
		
		sin.close(); f1.close(); f2.close();
		
	}

}
