package InputOutputStream;

public class ByteArrayOutputStreamDemo {

	public static void main(String[] args) {
		
	}

}
