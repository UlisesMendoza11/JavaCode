package InputOutputStream;
import java.io.*;
public class FileDemo {

	public static void main(String[] args) throws Exception {
		File f = new File("");
		if(f.createNewFile()) {
			System.out.println("New File is created");
		} else {
			System.out.println("File already exists");
		}
		
		String path = f.getAbsolutePath();
		System.out.println("File path is: " + path);
		
		File f1 = new File("");
		String fileList[] = f1.list();
		for(String fileName: fileList) {
			System.out.println(fileName);
		}
	}

}
