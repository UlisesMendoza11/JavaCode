package InputOutputStream;
import java.io.*;

class Employee implements Serializable {
	
	int empid;
	String name;
	String department;
	
	Employee(int empid, String name, String department) {
		this.empid = empid;
		this.name = name;
		this.department = department;
	}
}

public class EmployeeSerialization {

	public static void serializeEmp(Employee e, String path) throws Exception {
		FileOutputStream fout = new FileOutputStream(path);
		ObjectOutputStream out = new ObjectOutputStream(fout);
		out.writeObject(e); out.flush(); out.close();
	}
	
	public static void deserializeEmp(String path) throws Exception {
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(path));
		Employee e = (Employee)in.readObject();
		
		System.out.println(e.empid + " " + e.name + " " + e.department); in.close();
	}
	
	public static void main(String[] args) {
		Employee e1 = new Employee(10012, "John", "Testing");
		String path = "C:\\Users\\HP\\Desktop\\serialtest1.txt";
		try {
			serializeEmp(e1, path);
			System.out.println("Success");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			deserializeEmp(path);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
