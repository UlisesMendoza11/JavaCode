package InputOutputStream;
import java.io.*;
public class FileReaderDemo {

	public static void main(String[] args) throws Exception {
		FileReader fr = new FileReader("C:\\Users\\HP\\Desktop\\test1.txt");
		
		int i;
		
		while((i = fr.read()) != -1) {
			System.out.println((char) i);
		}
		
	}

}
