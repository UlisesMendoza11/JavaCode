package InputOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
/**
 * 3 types of streams: output, input, error
 * 
 * Output:
 * FileOutputStream
 * ByteArrayOutputStream
 * FilterOutputStream
 * PipedOutputStream
 * ObjectOutputStream
 * BufferedOutputStream
 * PrintStream
 * 
 * Input:
 * FileInputStream
 * ByteArrayInputStream
 * FileInputStream
 * DataInputStream
 * BufferedInputStream
 * PushBackInputStream
 * 
 */


public class StreamDemo {

	public static void main(String[] args) {
		
		try {
			FileOutputStream fout = new FileOutputStream("c:\\Users\\HP\\Desktop\\test1.txt");
			fout.write(99); fout.write(100);
			fout.flush();
			System.out.println("Success");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			FileOutputStream fout = new FileOutputStream("c:\\Users\\HP\\Desktop\\test2.txt");
			String s = "Java file input and output stream";
			byte b[] = s.getBytes();
			fout.write(b);
			fout.flush();
			System.out.println("Success...");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			FileInputStream fin = new FileInputStream("c:\\Users\\HP\\Desktop\\test1.txt");
			int i = fin.read();
			System.out.println((char) i);
			
			FileInputStream fin1 = new FileInputStream("c:\\Users\\HP\\Desktop\\test2.txt");
			int j = 0;
			while((j = fin1.read()) != -1) {
				System.out.println((char) i);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
