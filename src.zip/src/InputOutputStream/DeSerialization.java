package InputOutputStream;
import java.io.*;

public class DeSerialization {

	public static void main(String[] args) throws Exception {
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(""));
		Student s = (Student)in.readObject();
		
		System.out.println(s.id + " " + s.name); in.close();
	}
}
