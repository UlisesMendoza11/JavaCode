package Inheritance;
import java.util.Scanner;
class Animal
{
	public void eat() {
		System.out.println("Eating...");
	}
}

class Mammal extends Animal
{
	public void walk() { System.out.println("Walking..."); }
}

class Bird extends Animal
{
	public void fly() { System.out.println("Flying..."); }
}


class Shape
{
	double radius, side;
	Scanner sc = new Scanner(System.in);
	
	
	void data() {
		System.out.println("Enter the radius value");
		radius = sc.nextDouble();
		
		System.out.println("Enter the side value");
		side = sc.nextDouble();
	}
}

class Circle extends Shape
{
	double circleArea()
	{
		return 2*3.14*radius;
	}
}

class Square extends Shape
{
	double squareArea()
	{
		return side*side;
	}
}


public class HierarchicalInheritance {

	public static void main(String[] args) {
		Mammal m = new Mammal();
		m.eat(); m.walk();
		Bird b = new Bird();
		b.eat(); b.fly();
		
		Circle c = new Circle(); c.data();
		System.out.println("Area of circle = " + c.circleArea());
		Square s = new Square(); s.data();
		System.out.println("Area of square = " + s.squareArea());
	}
}
