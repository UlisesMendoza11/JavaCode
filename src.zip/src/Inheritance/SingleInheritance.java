package Inheritance;
import java.util.Scanner;

class Vehicle
{
	String brand;
	
	void drive()
	{
		System.out.println("Driving a " + brand + " vehicle");
	}
}

class Car extends Vehicle
{
	Car(String brand)
	{
		this.brand = brand;
	}
	
	void start() {
		System.out.println("Starting the " + brand + " car");
	}
}


class Product
{
	int pid, price, no_of_products;
	String pname;
	
	Scanner sc = new Scanner(System.in);
	
	void product_details()
	{
		System.out.print("Enter the product id: ");
		pid = sc.nextInt(); sc.nextLine();
		
		System.out.print("Enter the product name: ");
		pname = sc.nextLine();
		
		System.out.print("Enter the product price: ");
		price = sc.nextInt();
		
		System.out.print("Enter the no of products: ");
		no_of_products = sc.nextInt();
	}
}

class Accounts extends Product
{
	
	int discount, billAmt = price*no_of_products;
	
	void Calculate()
	{
		
		if (billAmt >= 10000)
		{
			discount = billAmt*15/100;
		} else {
			discount = billAmt*5/100;
		}
	}
	
	void receipt()
	{
		System.out.println("Product Code: " + pid);
		System.out.println("Product Name: " + pname);
		System.out.println("Product Price: " + price);
		System.out.println("No of Products: " + no_of_products);
		System.out.println("Bill Amount: " + billAmt);
	}
}

public class SingleInheritance {

	public static void main(String[] args) {
		Accounts account = new Accounts();
		account.product_details(); account.Calculate(); account.receipt();
		
		Car myCar = new Car("Toyota"); myCar.start(); myCar.drive();
	}

}
