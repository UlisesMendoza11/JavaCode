package Inheritance;

class Employee1
{
	void report()
	{
		System.out.println("from Employee1 class");
	}
}

class Product1
{
	void report()
	{
		System.out.println("from Product class");
	}
}

class Accounts1 extends Employee1
{
	void report()
	{
		System.out.println("from Accounts class");
	}
}

public class MultipleInheritance {

	public static void main(String[] args) {
		Accounts1 a = new Accounts1();
		a.report();
	}

}
