package Inheritance;

class EmployeeData
{
	private int empid, salary, contactNo;
	private String name, address;
	
	public int getEmpid() {
		return empid;
	}
	
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	
	public int getSalary() {
		return salary;
	}
	
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public int getContactNo() {
		return this.contactNo;
	}
	
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
}


class PersonalAccount
{
	private int accNo, accBal;
	private String name, address, branch;
	
	public int getAccNo() {
		return accNo;
	}
	
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	
	public int getAccBal() {
		return accBal;
	}
	
	public void setAccBal(int accBal) {
		this.accBal = accBal;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getBranch() {
		return branch;
	}
	
	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	PersonalAccount(int accNo, int accBal, String name, String address, String branch) {
		this.accNo = accNo;
		this.accBal = accBal;
		this.name = name;
		this.address = address;
		this.branch = branch;
	}
}

public class EncapsulationDemo {

	public static void main(String[] args) {
		EmployeeData e = new EmployeeData();
		e.setEmpid(10011); System.out.println("Employee Id: " + e.getEmpid());
		e.setName("Joseph"); System.out.println("Employee Name: " + e.getName());
		e.setSalary(55000); System.out.println("Employee Salary: " + e.getSalary());
		e.setContactNo(5467777); System.out.println("Employee ContactNo: " + e.getContactNo());
		e.setAddress("Joseph"); System.out.println("Employee Address: " + e.getAddress());
		
		PersonalAccount acc = new PersonalAccount(10011, 5000, "John Doe", "123 Main Street", "");
	}

}
