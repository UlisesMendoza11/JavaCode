package Inheritance;

class Person
{
	String name;
	int age;
	
	Person(String name, int age)
	{
		this.name = name;
	}
	
	void person_data()
	{
		System.out.println("Name: " + name + " and Age: " + age);
	}
	
	void introduce() {
		System.out.println("Hi My name is: " + name + " and I am " + age + " years old");
	}
}

class Employee extends Person
{
	int salary;
	Employee(String name, int age, int salary) {
		super(name, age); this.salary = salary;
	}
	
	void salaryData() {
		System.out.println("Salary is: " + salary);
	}
}


class Manager extends Employee {
	String department;
	
	Manager(String name, int age, int salary, String department) {
		super(name, age, salary); this.department = department;
	}
	
	void EmployeeDetails()
	{
		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
		System.out.println("Salary: " + salary);
		System.out.println("Department: " + department);
	}
}

class Student extends Person
{
	int studentId;
	
	Student(String name, int age, int studentId) {
		super(name, age); this.studentId = studentId;
	}
	
	void study() { System.out.println("I am Studying"); }
}

class Graduate extends Student {
	
	String major;
	
	Graduate(String name, int age, int studentId, String major) {
		super(name, age, studentId); this.major = major;
	}
	
	void declareMajor() {
		System.out.println("I am studying my major in " + major);
	}
}


public class MultiLevelInheritance {
	
	public static void main(String[] args) {
		Graduate graduate = new Graduate("John", 19, 10075, "Computer Science");
		graduate.introduce(); graduate.study(); graduate.declareMajor();
		
		System.out.println("==============================");
		
		Graduate graduate1 = new Graduate("Joy", 15, 10033, "ECE");
		graduate1.introduce(); graduate1.study(); graduate1.declareMajor();
		
		System.out.println("==============================");
		
		Manager m = new Manager("Rosey", 22, 55000, "Developement");
		m.EmployeeDetails();
		
		Manager m1 = new Manager("Jacob", 25, 63000, "Developement");
		m1.EmployeeDetails();
	}

}
