package Inheritance;

class Address
{
	String street, city, state, zip;
	
	Address(String street, String city, String state, String zip) {
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
	}
}

class Employee2
{
	int id;
	String name;
	Address address;
	
	Employee2(int id, String name, Address address) {
		this.id = id;
		this.name = name;
		this.address = address;
	}
}

public class AggregationInheritance {
	
	public static void main(String[] args) {
		Address a = new Address("123 Main Street", "Anytown", "CA", "12345");
		Employee2 e = new Employee2(10011, "Hendry", a);
		System.out.println("Employee Id: " + e.id);
		System.out.println("Employee Name: " + e.name);
		System.out.println("Street: " + a.street);
		System.out.println("City: " + a.city);
		System.out.println("Zip Code: " + a.zip);
		
	}

}
