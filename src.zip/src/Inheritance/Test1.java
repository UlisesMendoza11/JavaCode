package Inheritance;

class University
{
	String sname, cname, dept;
	int sid, cid;
}

class Student1 extends University
{
	Student1(String sname, int sid, String dept) {
		this.sname = sname;
		this.sid = sid;
		this.dept = dept;
	}
	
	void studentInfo() {
		System.out.println("Student Name: " + this.sname);
		System.out.println("Student Id: " + this.sid);
		System.out.println("Department: " + this.dept);
	}
}

class Course extends University
{
	Course(String cname, int cid, String dept) {
		this.cname = cname;
		this.cid = cid;
		this.dept = dept;
	}
	
	void courseInfo() {
		System.out.println("Course Name: " + this.cname);
		System.out.println("Course Id: " + this.cid);
		System.out.println("Department: " + this.dept);
	}
}

public class Test1 {

	public static void main(String[] args) {
		Student1 s = new Student1("John Doe", 10011, "Computer Science"); s.studentInfo();
		System.out.println();
		Course c = new Course("Intro to C++", 40501, "Computer Science"); c.courseInfo();
	}

}
