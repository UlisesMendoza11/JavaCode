package MultiThreading;

class MyThread4 implements Runnable
{
	private final Object lock;
	
	MyThread4(Object lock) {
		this.lock = lock;
	}
	
	public void run() {
		synchronized(lock) {
			System.out.println(Thread.currentThread().getName() + " is waiting ...");
			try {
				lock.wait();
			} catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName() + " is awake! ...");
		}
	}
}

public class NotifyDemo {

	public static void main(String[] args) {
		Object lock = new Object();
		Thread t1 = new Thread(new MyThread4(lock), "Thread 1");
		Thread t2 = new Thread(new MyThread4(lock), "Thread 2");
		
		t1.start(); t2.start();
		
		try {
			Thread.sleep(3000);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		synchronized(lock) {
			lock.notify();
		}
	}

}
