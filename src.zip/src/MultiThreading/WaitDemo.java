package MultiThreading;

public class WaitDemo {

	public static void main(String[] args) {
		Object lock = new Object();
		
		Thread t1 = new Thread(() -> {
			synchronized(lock) {
				try { lock.wait(); }
				catch (Exception e) { e.printStackTrace(); }
				System.out.println("Thread 1 resumed execution");
			}
		});
		
		Thread t2 = new Thread(() -> {
			synchronized(lock) {
				try { lock.wait(); }
				catch (Exception e) { e.printStackTrace(); }
				System.out.println("Thread 1 resumed execution");
			}
		});
		
		t1.start(); t2.start();
	}

}
