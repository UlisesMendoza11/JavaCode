package MultiThreading;

public class MultiTask {

	public static void main(String[] args) {
		Thread task1 = new Thread(new Runnable(){
			public void run()
			{
				for(int i = 0; i < 5; i++) {
					if(i % 2 == 0) {
						try {
							System.out.println("from task1: " + i);
							Thread.sleep(2000);
						} catch(Exception e) {
							System.out.println(e);
						}
					}
				}
			}
		});
		
		Thread task2 = new Thread(new Runnable(){
			public void run()
			{
				for(int i = 0; i < 5; i++) {
					if(i % 2 == 0) {
						try {
							System.out.println("from task2: " + i);
							Thread.sleep(2000);
						} catch(Exception e) {
							System.out.println(e);
						}
					}
				}
			}
		});
		
		Thread task3 = new Thread(new Runnable(){
			public void run()
			{
				for(int i = 0; i < 5; i++) {
					if(i % 2 == 0) {
						try {
							System.out.println("from task3: " + i);
							Thread.sleep(2000);
						} catch(Exception e) {
							System.out.println(e);
						}
					}
				}
			}
		});
			
		task1.start(); task2.start(); task3.start();
		System.out.println("Main thread exiting...");
	}

}
