package MultiThreading;

class MyThread extends Thread
{
	public void run()
	{
		for(int i = 0; i < 5; i++) {
			System.out.println(i*i);
		}
	}
}

class Thread1 extends Thread
{
	public void run()
	{
		System.out.println("Thread is running");
	}
}

class Thread2 implements Runnable
{
	public void run()
	{
		for(int i = 0; i < 5; i++) {
			System.out.println(i = i*i);
		}
		System.out.println("Thread Completed");
	}
}

public class ThreadLifeCycle {

	public static void main(String[] args) {
		MyThread m = new MyThread();
		System.out.println("Thread State: " + m.getState());
		m.start();
		System.out.println("Thread State: " + m.getState());
		
		try {
			m.join();
		} catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Thread State: " + m.getState());
		
		Thread1 t1 = new Thread1();
		t1.start();

		Thread1 t2 = new Thread1();
		t2.start();
		
		Thread1 t3 = new Thread1();
		t3.start();
		
		
		Thread myT = new Thread(new Thread2());
		myT.start();
		
		Thread t4 = new Thread(new Thread2());
		t4.start();
	}

}
