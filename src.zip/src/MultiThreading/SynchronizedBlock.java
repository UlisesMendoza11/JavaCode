package MultiThreading;

public class SynchronizedBlock {

	private int count = 0;
	
	private void increment()
	{
		synchronized(this) {
			count++;
		}
	}
	
	public int getCount() { 
		synchronized(this)
		{
			return count;
		}
	}
	
	public static void main(String[] args) {
		final SynchronizedBlock obj = new SynchronizedBlock();
		
		Thread t1 = new Thread(() -> {
			for(int i = 0; i < 1000; i++) {
				obj.increment();
			}
		});
		
		Thread t2 = new Thread(() -> {
			for(int i = 0; i < 1000; i++) {
				obj.increment();
			}
		});
		
		t1.start(); t2.start();

		try {
			t1.join();
			t2.join();
		} catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Counter Value: " + obj.getCount());
	}

}
