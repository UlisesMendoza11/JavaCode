package MultiThreading;

/**
 * Synchronization in java is the capability to control
 * the access of multiple threads to any shared resource.
 * 
 * Advantages: prevents thread interference and consistency problem
 * 
 * Types: Process and Thread Sync
 * 
 * Thread Sync:
 * 
 * 1) Mutual Exclusive
 * 		- synchronized method
 * 		- synchronized block
 * 		- static synchronization
 */


class Table
{
	synchronized void printTable(int n)
	{
		for(int i = 1; i <= 5; i++) {
			System.out.println(n*i);
			try {
				Thread.sleep(2000);
			} catch(Exception e) {
				System.out.println(e);
			}
		}
	}
}

class MyThread1 extends Thread
{
	Table t;
	
	MyThread1(Table t) {
		this.t = t;
	}
	
	public void run()
	{
		t.printTable(5);
	}
}

class MyThread2 extends Thread
{
	Table t;
	
	MyThread2(Table t) {
		this.t = t;
	}
	
	public void run()
	{
		t.printTable(100);
	}
}

class MyThread3 extends Thread
{
	Table t;
	
	MyThread3(Table t) {
		this.t = t;
	}
	
	public void run()
	{
		t.printTable(7);
	}
}

public class SynchronizationDemo {

	public static void main(String[] args) {
		Table obj = new Table();
		MyThread1 t1 = new MyThread1(obj);
		MyThread2 t2 = new MyThread2(obj);
		MyThread3 t3 = new MyThread3(obj);
		
		t1.start(); t2.start(); t3.start();
	}

}
