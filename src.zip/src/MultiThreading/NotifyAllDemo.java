package MultiThreading;

public class NotifyAllDemo {

	public static void main(String[] args) {
		Object lock = new Object();
		Thread t1 = new Thread(new MyThread4(lock), "Thread1");
		Thread t2 = new Thread(new MyThread4(lock), "Thread1");
		
		t1.start();
		t2.start();
		
		try {
			Thread.sleep(3000);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		synchronized(lock) {
			lock.notifyAll();
		}
	}

}
