package MultiThreading;
import java.util.concurrent.*;



public class WorkerThread implements Runnable {
	
	private String message;
	public WorkerThread(String s)
	{
		this.message = s;
	}

	public void run()
	{
		System.out.println(Thread.currentThread().getName() + "(start) message = " + message);
		processMessage();
		System.out.println(Thread.currentThread().getName() + "(end)");
	}
	
	private void processMessage()
	{
		try {
			Thread.sleep(3000);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		ExecutorService exe = Executors.newFixedThreadPool(5);
		
		for(int i = 0; i < 10; i++) {
			Runnable worker = new WorkerThread("" + i);
			exe.execute(worker);
		}
		exe.shutdown();
		while(!exe.isTerminated()) {
			System.out.println("Finished all threads");
		}
	}

}
