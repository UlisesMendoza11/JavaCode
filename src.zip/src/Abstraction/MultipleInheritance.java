package Abstraction;

interface Flyable
{
	public void fly();
}

interface Swimmable
{
	public void swim();
}

class Duck implements Flyable, Swimmable
{
	@Override
	public void swim()
	{
		System.out.println("Duck is swimming");
	}
	
	@Override
	public void fly()
	{
		System.out.println("Duck is flying");
	}
}

public class MultipleInheritance {

	public static void main(String[] args) {
		Duck d = new Duck();
		d.swim(); d.fly();
	}

}
