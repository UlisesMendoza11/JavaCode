package Abstraction;

interface Drawable
{
	public void draw();
}

interface Resizable extends Drawable
{
	public void resize(double factor);
}

class Rectangle1 implements Resizable
{
	private double width, height;
	
	Rectangle1(double width, double height)
	{
		this.width = width;
		this.height = height;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}
	
	@Override
	public void draw()
	{
		System.out.println("Drawing rectangle");
	}
	
	@Override
	public void resize(double factor) {
		width *= factor;
		height *= factor;
	}
}

public class InterfaceInheritance {

	public static void main(String[] args) {
		Rectangle1 r = new Rectangle1(5.0, 6.0);
		r.draw();
		System.out.println("Width: " + r.getWidth() + ", Height: " + r.getHeight());
		
		r.resize(2.0);
		System.out.println("Width: " + r.getWidth() + ", Height: " + r.getHeight());

	}
}
