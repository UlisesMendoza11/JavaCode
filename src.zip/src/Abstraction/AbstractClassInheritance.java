package Abstraction;

abstract class Shape1
{
	abstract void draw();
}

abstract class Circle extends Shape1
{
	abstract int area(int s);
}

class Square extends Circle
{
	@Override
	int area(int s) {
		return s*s;
	}
	
	@Override
	void draw() {
		System.out.println("Square is drawing");
	}
}

class Rectangle extends Circle
{
	@Override
	int area(int s) {
		return s*s*s;
	}
	
	@Override
	void draw() {
		System.out.println("Rectangle is drawing");
	}
}


public class AbstractClassInheritance {

	public static void main(String[] args) {
		Square s = new Square(); System.out.println(s.area(10)); s.draw();
		Rectangle r = new Rectangle(); System.out.println(r.area(10)); r.draw();
	}

}
