package Abstraction;

abstract class Loan
{
	abstract int roi();
}

class PersonalLoan extends Loan
{
	@Override
	int roi() {
		return 12;
	}
}

class HomeLoan extends Loan
{
	@Override
	int roi() {
		return 10;
	}
}


class CarLoan extends Loan
{
	@Override
	int roi() {
		return 11;
	}
}

public class AbstractClass {
	
	public static void main(String[] args) {
		PersonalLoan p = new PersonalLoan();
		System.out.println("Personal Loan Rate of Interest" + p.roi() + "%");
		
		HomeLoan h = new HomeLoan();
		System.out.println("Home Loan Rate of Interest" + h.roi() + "%");
		
		CarLoan c = new CarLoan();
		System.out.println("Car Loan Rate of Interest" + c.roi() + "%");
	}
}
