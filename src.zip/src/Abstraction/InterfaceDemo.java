package Abstraction;

interface Shape
{
	public double getArea();
	public double getPerimeter();
}

class Circle1 implements Shape
{
	public double radius;
	
	public Circle1(double radius) {
		this.radius = radius;
	}
	
	public double getRadius() {
		return this.radius;
	}
	
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	@Override
	public double getArea() {
		return Math.PI*radius*radius;
	}
	
	@Override
	public double getPerimeter() {
		return 2*Math.PI*radius;
	}
}

public class InterfaceDemo {

	public static void main(String[] args) {
		Circle1 c = new Circle1(5.0);
		System.out.println("Radius: " + c.getRadius());
		System.out.println("Area: " + c.getArea());
		System.out.println("Perimeter: " + c.getPerimeter());

	}

}
