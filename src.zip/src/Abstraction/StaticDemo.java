package Abstraction;

interface Bank
{
	public float roi();
	static void show() {
		System.out.println("Static method from interface");
	}
	
	default void display() {
		System.out.println("Default method from interface");
	}
}

class ICICI implements Bank
{
	@Override
	public float roi() {
		return 12.5f;
	}
	
	public void display() {
		System.out.println("method from child class");
	}
}

class HDFC implements Bank
{
	@Override
	public float roi() {
		return 14.8f;
	}
}

public class StaticDemo {

	public static void main(String[] args) {
		ICICI i = new ICICI();
		System.out.println("ICICI Rate of Interest: " + i.roi()); i.display();
		
		HDFC h = new HDFC();
		System.out.println("HDFC Rate of Interest: " + h.roi()); h.display();
		Bank.show(); h.display();
	}

}
