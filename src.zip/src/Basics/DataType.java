package Basics;

public class DataType {

	public static void main(String[] args) {
		String name = "Jackson";
		int age = 34;
		float height = 165.58f;
		double weight = 65.89d;
		boolean result = true;
		char gender = 'M';
		
		System.out.println("String Data type: " + name);
		System.out.println("Integer Data type: " + age);
		System.out.println("Float Data type: " + height);
		System.out.println("Double Data type: " + weight);
		System.out.println("Boolean Data type: " + result);
		System.out.println("Char Data type: " + gender);
	}

}
