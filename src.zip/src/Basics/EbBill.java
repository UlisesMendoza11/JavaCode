package Basics;

public class EbBill {

	public static void main(String[] args) {
		String cus_name, address;
		float billAmt;
		int tot_units, meterNo, price_per_unit;
		
		cus_name = "Alex"; address = "chicago";
		price_per_unit = 10;
		tot_units = 200;
		billAmt = price_per_unit * tot_units;
		meterNo = 10056;
		
		System.out.println("EB Bill Receipt");
		System.out.println("Consumer Name: " + cus_name);
		System.out.println("Consumer Address: " + address);
		System.out.println("Eb Number: " + meterNo);
		System.out.println("Bill Amount" + billAmt);
		
		
	}

}
