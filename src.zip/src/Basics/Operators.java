package Basics;

public class Operators {

	public static void main(String[] args) {
		System.out.println("Arithmetic Operators");
		int a = 10, b = 10, c = 5;
		
		System.out.println("Addition: " + (a+b));
		System.out.println("Subtraction: " + (a-b));
		System.out.println("Multiplication: " + (a*b));
		System.out.println("Division: " + (a/b));
		System.out.println("Modulus: " + (a%b));
		
		System.out.println("Relational Operators");
		System.out.println("Greater than: " + (a>c));
		System.out.println("Less than: " + (a<b));
		System.out.println("Greater than or equal:" + (a>=b));
		System.out.println("Less than or equal:" + (a<=b));
		System.out.println("Equal:" + (a==b));
		System.out.println("Not equal:" + (a!=b));
		
		System.out.println("Logical Operators");
		int x = 10, y = 5, z = 9;
		System.out.print("AND operator all the conditions should be true: ");
		System.out.println(x<y && x>z);
		System.out.print("OR operator any one condition should be true: ");
		System.out.println(x<y || x>z);
		System.out.print("NOT operator gives opposite result:");
		System.out.println(!(x<y));
		
		System.out.println("Assignment Operators");
		System.out.println("a=a+b: " + (a+=b));
		System.out.println("a=a-b: " + (a-=b));
		System.out.println("a=a*b: " + (a*=b));
		System.out.println("a=a/b: " + (a/=b));
		System.out.println("a=a%b: " + (a%=b));
		
		System.out.println("Bitwise Operators");
		System.out.print("AND operator all the conditions should be true: ");
		System.out.println(x<y & x>z);
		System.out.print("OR operator any one condition should be true: ");
		System.out.println(x<y | x>z);
		System.out.print("NOT operator gives opposite result:");
		System.out.println(!(x<y));
		
		System.out.println("Ternary Operators");
		int result = (x < y ? x : y);
		System.out.println("result = " + result);
		
		System.out.println("Unary Operators");
		System.out.println("Pre increment: " + (++x));
		System.out.println("Post increment: " + (x++));
		System.out.println("x: " + (x));
		System.out.println("Pre increment: " + (--y));
		System.out.println("Post increment: " + (y--));
		System.out.println("y: " + (y));
	}

}
