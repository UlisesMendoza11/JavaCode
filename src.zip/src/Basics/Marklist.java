package Basics;
import java.util.Scanner;

public class Marklist {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int regNo;
		String studentName;
		double score1, score2, score3, total, avg;
		
		System.out.print("Enter registration number: ");
		regNo = sc.nextInt();
		sc.nextLine();
		System.out.print("Enter the student name: ");
		studentName = sc.nextLine();
		System.out.print("Enter first test score: ");
		score1 = sc.nextDouble();
		System.out.print("Enter second test score: ");
		score2 = sc.nextDouble();
		System.out.print("Enter third test score: ");
		score3 = sc.nextDouble();
		total = score1+score2+score3;
		avg = total/3.0;
//		char grade;
//		if (avg >= 90.0) {
//			grade = 'A';
//		} else if (avg >= 80.0) {
//			grade = 'B';
//		} else if (avg >= 70.0) {
//			grade = 'C';
//		} else if (avg >= 60.0) {
//			grade = 'D';
//		} else {
//			grade = 'F';
//		}
		System.out.println(studentName + "'s Marklist");
		System.out.println("Score1 = " + score1);
		System.out.println("Score2 = " + score2);
		System.out.println("Score3 = " + score3);
		System.out.println("Total Score = " + total);
		System.out.println("Average Score = " + avg);
//		System.out.println("Grade " + grade);
		if (avg > 80) {
			System.out.println("You are in first class");
		} else if (avg > 70) {
			System.out.println("You are in second class");
		} else {
			System.out.println("You are in third class");
		}
		
		sc.close();
	}

}
