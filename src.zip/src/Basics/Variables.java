package Basics;

public class Variables {

	public static void main(String[] args) {
		String name;
		int age;
		float weight, height;
		
		name="john";
		age=25;
		height= 160.00f;
		weight=65.00f;
		
		System.out.println("Name is: " + name);
		System.out.println("Age is: " + age);
		System.out.println("Height is: " + height);
		System.out.println("Weight is: " + weight);
	}

}
