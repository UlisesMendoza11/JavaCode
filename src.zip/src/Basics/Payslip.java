package Basics;
import java.util.Scanner;

public class Payslip {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String empName;
		int empId, bas_Sal, pf, esi, hra, da, tot_ear, tot_ded, net_pay;
		System.out.print("Enter the Employee Name: ");
		empName = sc.next();
		System.out.println("Enter the Employee Id: ");
		empId = sc.nextInt();
		System.out.println("Enter the Base Salary");
		bas_Sal = sc.nextInt();
		
		pf = bas_Sal*12/100;
		esi = bas_Sal*14/100; hra = bas_Sal*25/100;
		da = bas_Sal*20/100; tot_ear = bas_Sal + hra + da;
		tot_ded = pf + esi; net_pay = tot_ear - tot_ded;
		
		System.out.println("==========================");
		System.out.println("========PAYSLIP===========");
		System.out.println("==========================");
		System.out.println("Employee Name: " + empName);
		System.out.println("Employee Id: " + empId);
		System.out.println("Employee Name: " + empName);
		System.out.println("Base Salary: " + bas_Sal);
		System.out.println("Hra: " + hra);
		System.out.println("Da: " + da);
		System.out.println("PF: " + pf);
		System.out.println("ESI: " + esi);
		System.out.println("Total Earnings: " + tot_ear);
		System.out.println("Total Deduction: " + tot_ded);
		System.out.println("Net Salary: " + net_pay);
		
	}

}
