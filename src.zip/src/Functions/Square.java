package Functions;
import java.util.Scanner;
public class Square {

	float side, area, circum;
	Scanner sc = new Scanner(System.in);
	
	float calArea()
	{
		System.out.print("Enter the value for side: ");
		side = sc.nextFloat();
		float result = side*side;
		
		return result;
	}
	
	void calCircum()
	{
		System.out.print("Enter the value for side: ");
		side = sc.nextFloat();
		float result = side*4;
		
		System.out.println("Circumference of the Square is: " + result);
	}
	
	public static void main(String[] args) {
		Square s = new Square();
		s.calCircum(); s.calCircum();
		
		System.out.println(s.calArea());
		
		float square_circum = s.calArea();
		System.out.println(square_circum);
	}

}
