package Functions;
import java.util.Scanner;
public class EmployeePayslip {

	static Scanner sc = new Scanner(System.in);
	static int eno;
	static String name;
	static double bas_sal, pf, esi, hra, da, total_ear, total_ded, gross_pay;
	
	static void collectData()
	{
		System.out.print("Enter Employee No: ");
		eno = sc.nextInt();
		
		sc.nextLine();
		System.out.print("Enter Employee Name: ");
		name = sc.nextLine();
		
		System.out.print("Enter Base Salary: ");
		bas_sal = sc.nextDouble();
	}
	
	static void callPayslip()
	{
		pf = bas_sal*12/100.0;
		esi = bas_sal*14/100.0;
		hra = bas_sal*35/100.0;
		da = bas_sal*25/100.0;
		total_ear = bas_sal + hra + da;
		total_ded = pf + esi;
		gross_pay = total_ear - total_ded;
	}
	
	static void report()
	{
		System.out.println("Employee Paylist:");
		System.out.println("Employee No: " + eno);
		System.out.println("Employee Name: " + name);
		System.out.println("Base Salary: " + bas_sal);
		System.out.println("pf: " + pf);
		System.out.println("esi: " + esi);
		System.out.println("hra: " + hra);
		System.out.println("da: " + da);
		System.out.println("Total Earned: " + total_ear);
		System.out.println("Total Deducted: " + total_ded);
		System.out.println("Gross Pay: " + gross_pay);
	}
	
	public static void main(String[] args) {
		collectData(); callPayslip(); report();
	}

}
