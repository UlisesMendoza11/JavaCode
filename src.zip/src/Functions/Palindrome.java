package Functions;
import java.util.Scanner;
public class Palindrome {

	
	static String str;
	static Scanner sc = new Scanner(System.in);
	
	static void printString()
	{
		for (int i = 0; i < str.length(); i++) {
			System.out.print(str.charAt(i));
		}
		System.out.println();
	}
	
	static void isPalindrome()
	{
		boolean isPal = true;
		for (int i = 0; i < str.length()/2; i++) {
			if (str.charAt(i) != str.charAt(str.length()-i-1)) {
				System.out.println(str + " is not a palindrome");
				isPal = false;
				break;
			}
		}
		if (isPal) {
			System.out.println(str + " is a palindrome");
		}
	}
	
	static void collectString()
	{
		System.out.print("Enter string: ");
		str = sc.nextLine();
	}
	
	static int wordCount()
	{
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			char temp = str.charAt(i);
			// reached a space or the end of the string
			if (temp == ' ' || temp == '\n') {
				count++;
			}
		}
		return count;
	}
	
	public static void main(String[] args) {
		collectString(); isPalindrome();
	}

}
