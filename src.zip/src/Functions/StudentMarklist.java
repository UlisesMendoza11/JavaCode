package Functions;
import java.util.Scanner;

public class StudentMarklist {

	static int regno, sub1, sub2, sub3, tot, avg;
	static String name, result, grade;
	static Scanner sc = new Scanner(System.in);
	
	static void getData()
	{
		System.out.println("Enter the Student Regno");
		regno = sc.nextInt();
		
		sc.nextLine();
		System.out.println("Enter the Student Name");
		name = sc.nextLine();
		
		System.out.println("Enter the Mark for Subject1");
		sub1 = sc.nextInt();
		
		System.out.println("Enter the Mark for Subject2");
		sub2 = sc.nextInt();
		
		System.out.println("Enter the Mark for Subject3");
		sub3 = sc.nextInt();
	}
	
	static void calculation()
	{
		tot = sub1 + sub2 + sub3;
		avg = tot / 3;
		if (sub1 >= 40 && sub2 >= 40 && sub3 >= 40) {
			result = "Pass";
			if (avg >= 80)
			{
				grade = "A";
			} 
			else if (avg < 80 && avg >= 70) {
				grade = "B";
			}
			else {
				grade = "C";
			}
		}
		else {
			result = "fail";
		}
	}
	
	static void report()
	{
		System.out.println("Mark List");
		System.out.println("Register Number: " + regno);
		System.out.println("Student Name: " + name);
		System.out.println("Subect1 Mark: " + sub1);
		System.out.println("Subect2 Mark: " + sub2);
		System.out.println("Subect3 Mark: " + sub3);
		System.out.println("Total: " + tot);
		System.out.println("Average: " + avg);
		System.out.println("Result: " + result);
		System.out.println("Grade: " + grade);
	}
	
	public static void main(String[] args) {
		getData(); calculation(); report();
	}

}
