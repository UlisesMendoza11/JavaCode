package Functions;

public class Demo {

	
	public static int addNumbers(int x, int y) {
		int sum = x + y;
		return sum;
	}
	public static void main(String[] args) {
		int num1 = 5;
		int num2 = 10;
		int result = addNumbers(num1, num2);
		System.out.println("The sum of " + num1 + " and " 
		+ num2 + " is " + result);
		System.out.println(addNumbers(34, 65));
		System.out.println(addNumbers(76, 45));
		System.out.println(addNumbers(34, 77));
		System.out.println(addNumbers(39, 546));
	}

}
