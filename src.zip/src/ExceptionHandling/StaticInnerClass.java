package ExceptionHandling;

class TestOuter
{
	static int data = 50;
	static class Inner {
		void msg() {
			System.out.println("Data from static inner class: " + data);
		}
	}
}

public class StaticInnerClass {

	public static void main(String[] args) {
		TestOuter.Inner obj = new TestOuter.Inner();
		obj.msg();
	}

}
