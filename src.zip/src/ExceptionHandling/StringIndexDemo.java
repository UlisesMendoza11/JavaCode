package ExceptionHandling;

public class StringIndexDemo {

	public static void main(String[] args) {
		try {
			String str = "Java Exception Handling";
			int len = str.length();
			
			System.out.println("Length of the string is: " + len);
			char ch = str.charAt(100);
		} catch (StringIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		System.out.println("After the exception...");
	}

}
