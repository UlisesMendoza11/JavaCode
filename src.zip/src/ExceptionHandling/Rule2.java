package ExceptionHandling;

class Parent1
{
	void msg() {
		System.out.println("Parent method");
	}
}

class Child1 extends Parent1
{
	void msg() throws ArithmeticException {
		System.out.println("Child method");
	}
}

public class Rule2 {

	public static void main(String[] args) {
		Child1 p = new Child1();
		p.msg();
	}

}
