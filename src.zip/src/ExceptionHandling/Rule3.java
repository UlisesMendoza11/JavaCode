package ExceptionHandling;

class Parent2
{
	void msg() throws ArithmeticException
	{
		System.out.println("Parent method");
	}
}

class Child2 extends Parent2
{
	void msg() throws ArithmeticException
	{
		System.out.println("Class method");
	}
}

public class Rule3 {

	public static void main(String[] args) {
		Child2 p = new Child2();
		p.msg();
	}

}
