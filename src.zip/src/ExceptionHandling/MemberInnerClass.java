package ExceptionHandling;

class TestMemberOuter
{
	private int x = 50;
	
	class Inner {
		void msg() { 
			System.out.println("x = " + x);
		}
	}
}

public class MemberInnerClass {

	public static void main(String[] args) {
		TestMemberOuter obj = new TestMemberOuter();
		TestMemberOuter.Inner obj1 = obj.new Inner();
		obj1.msg();
	}

}
