package ExceptionHandling;

class Person
{
	private String name;
	private int age;
	
	public Person(String name, int age) throws InvalidAgeException
	{
		this.name = name;
		if (age < 0 || age > 120) {
			throw new InvalidAgeException("Invalid Age");
		}
		this.age = age;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
}

class InvalidAgeException extends Exception
{
	public InvalidAgeException(String message)
	{
		super(message);
	}
}


class MyCustomException extends Exception
{
	public MyCustomException(String message) {
		super(message);
	}
}

public class CustomException {

	public static void main(String[] args) {
		try {
			throw new MyCustomException("This is my custom exception");
		} catch(MyCustomException e) {
			System.out.println(e.getMessage());
		}
		
		try {
			Person p = new Person("John", 125);
		} catch(InvalidAgeException e) {
			System.out.println(e.getMessage());
		}
	}

}
