package ExceptionHandling;

class DivideByZeroException extends Exception
{
	DivideByZeroException(String message) {
		super(message);
	}
}

public class OperationsDemo {

	int add(int x, int y) { 
		return x + y;
	}
	
	int subtract(int x, int y) {
		return x - y;
	}
	
	int multiply(int x, int y) {
		return x*y;
	}
	
	int divide(int x, int y) throws DivideByZeroException
	{
		if(y == 0) {
			throw new DivideByZeroException("Cannot divide by zero");
		}
		return x/y;
	}
	
	void display(int x, int y) {
		System.out.println("Add " + x + " and " + y + " : " + add(x,y));
		System.out.println("Subtract " + y + " from " + x + " : " + subtract(x,y));
		System.out.println("Multiply " + x + " and " + y + " : " + multiply(x,y));
		System.out.print("Divide " + x + " by " + y + ": ");
		try {
			System.out.println(divide(x,y));
		} catch (DivideByZeroException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void main(String[] args) {
		OperationsDemo d = new OperationsDemo();
		d.display(5, 0);
		d.display(1, 3);
		d.display(4, 2);
		d.display(3, 1);
	}

}
