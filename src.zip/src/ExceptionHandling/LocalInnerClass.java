package ExceptionHandling;

class LocalInner
{
	private int data = 30;
	
	void display() {
		class Local {
			void msg() { System.out.println("data from local inner class: " + data); }
		}
		Local l = new Local(); l.msg();
	}
}

public class LocalInnerClass {

	public static void main(String[] args) {
		LocalInner obj = new LocalInner();
		obj.display();
	}

}
