package ExceptionHandling;
import java.util.Scanner;


public class ArithmeticExceptionDemo {

	public static void main(String[] args) {
		try {
			int x, y, result, sum;
			System.out.println("Enter the value for x: ");
			Scanner sc = new Scanner(System.in);
			x = sc.nextInt();
			
			System.out.println("Enter the value for y: ");
			y = sc.nextInt();
			
			sum = x+y;
			
			System.out.println("X = " + x + " Y = " + y + " Sum = " + sum);
			result = sum/0;
		} catch (RuntimeException e) {
			System.out.println(e);
		}
		
		System.out.println("Rest of the code after exception");
		
	}

}
