package ExceptionHandling;

public class NumberFormatDemo {

	public static void main(String[] args) {
		try {
			String str = "abc123";
			int num = Integer.parseInt(str);
			System.out.println(num);
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Rest of the code...");
	}

}
