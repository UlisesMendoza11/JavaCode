package ExceptionHandling;

class Parent
{
	void msg()
	{
		System.out.println("Parent method");
		
	}
}

class Child extends Parent
{
	void msg()
	{
		System.out.println("Child method");
	}
}

public class Rule1 {

	public static void main(String[] args) {
		Child p = new Child();
		p.msg();
	}

}
