package ExceptionHandling;
import java.util.Scanner;

class LessThanEqualToZeroException extends Exception
{
	LessThanEqualToZeroException(String message) {
		super(message);
	}
}

public class FactorialDemo {

	int factorial(int num) {
		if (num == 1) {
			return 1;
		}
		return factorial(num-1) * num;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		FactorialDemo f = new FactorialDemo();
		int num;
		while(true) {
			try {
				System.out.print("Enter number to calculate factorial: ");
				num = sc.nextInt();
				if (num > 0) {
					break;
				}
				else {
					throw new LessThanEqualToZeroException("Number must be greater than 0. Try again");
					
				}
			} catch (LessThanEqualToZeroException e) {
				System.out.println(e.getMessage());
			}
		}
		System.out.println(f.factorial(num));
	}

}
