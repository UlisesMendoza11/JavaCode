package ExceptionHandling;

public class ThrowsDemo {

	static int divide(int x, int y) throws ArithmeticException
	{
		if(y == 0) {
			throw new ArithmeticException("Cannot divide by zero");
		}
		return x/y;
	}
	
	public static void main(String[] args) {
		System.out.println("Answer is: " + ThrowsDemo.divide(10,2));
		
		try {
			System.out.println("Answer is: " + ThrowsDemo.divide(10,2));
			System.out.println("Answer is: " + ThrowsDemo.divide(10,0));
		} catch (ArithmeticException e) {
			System.out.println(e);
		}
		System.out.println("Rest of the code...");
		
		
	}

}
