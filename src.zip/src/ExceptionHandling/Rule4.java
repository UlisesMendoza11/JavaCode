package ExceptionHandling;

class Parent3
{
	void msg() throws Exception
	{
		System.out.println("Parent method");
	}
}

class Child3 extends Parent3
{
	void msg() /* throws Exception */
	{
		System.out.println("Class method");
	}
}


public class Rule4 {

	public static void main(String[] args) {
		Child3 p = new Child3();
		p.msg();
	}

}
