package ExceptionHandling;

public class NullPointerDemo {

	public static void main(String[] args) {
		
		try {
			
			String s = "Hello World";
			int length = s.length();
			System.out.println("String is: " + s + " Length is: " + length);
			String s1 = null;
			int len = s1.length();
			System.out.println("String is: " + s1 + " Length is: " + len);
			
		} catch(NullPointerException e) {
			System.out.println(e);
		}
		
		System.out.println("rest of the code....");
	}

}
