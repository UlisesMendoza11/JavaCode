package ExceptionHandling;

public class ArrayIndexDemo {

	public static void main(String[] args) {
		
		try {
			int empNo[] = new int[10];
			
			empNo[5] = 10045;
			System.err.println("6th Employee id is: " + empNo[5]);
			empNo[11] = 50068;
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		System.out.println("After the exception...");
	}

}
