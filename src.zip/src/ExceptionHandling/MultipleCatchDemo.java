package ExceptionHandling;

public class MultipleCatchDemo {

	public static void main(String[] args) {
		try {
			int arr[] = new int[7];
			arr[10] = 20054/0;
		} catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		} catch(ArithmeticException e1) {
			System.out.println(e1);
		}
		System.out.println("Rest of the code");
	}

}
