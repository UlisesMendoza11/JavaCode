package ExceptionHandling;

public class FinallyDemo {

	public static void main(String[] args) {
		
		try
		{
			int x,y,result;
			x = 56;
			y = 32;
			result = x + y / 0;
			System.out.println("Result is: " + result);
		} catch (Exception e) {
			System.out.println("Inside Catch Clock: " + e);
		}
		finally {
			System.out.println("Finally will be executed always...");
		}
		System.out.println("Rest of the code...");
	}

}
