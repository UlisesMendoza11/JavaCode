package Collections;
import java.util.*;
// id, name, department, salary

class Employee1 {
	int id, salary;
	String name, department;
	
	Employee1(int id, String name, int salary, String department) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.department = department;
	}
}

public class EmployeeMap {

	public static void main(String[] args) {
		Employee1 e1 = new Employee1(10001, "John", 40000, "Development");
		Employee1 e2 = new Employee1(10002, "Alice", 60000, "Testing");
		Employee1 e3 = new Employee1(10003, "Mary", 35000, "Design");
		Employee1 e4 = new Employee1(10004, "David", 25000, "Maintenance");
		
		Map<Integer, Employee1> empMap = new HashMap();
		
		empMap.put(1, e1);
		empMap.put(2, e2);
		empMap.put(3, e3);
		empMap.put(4, e4);
		
		for(Map.Entry<Integer, Employee1>entry: empMap.entrySet()) {
			int key = entry.getKey();
			Employee1 e = entry.getValue();
			System.out.println(e.id + " " + e.name + " " + e.salary + " " + e.department);
		}
	}

}
