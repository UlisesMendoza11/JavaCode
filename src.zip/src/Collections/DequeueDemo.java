package Collections;
import java.util.*;
public class DequeueDemo {

	public static void main(String[] args) {
		Deque<Integer> dq = new ArrayDeque<Integer>();
		
		dq.add(10);
		dq.add(80);
		dq.add(40);
		dq.add(54);
		dq.add(23);
		dq.add(43);
		
		for(Integer i : dq) {
			System.out.println(i);
		}
		
		dq.pop();
		System.out.println(dq);
		
		Deque<String> deque = new ArrayDeque<String>();
		
		deque.add("John");
		deque.add("Mary");
		deque.add("David");
		deque.add("Michael");
		
		System.out.println("Array Deque: " + deque);
		deque.addFirst("Jessica");
		System.out.println("Add First: " + deque);
		deque.addLast("Katie");
		System.out.println("Add Last: " + deque);
		deque.removeFirst();
		System.out.println("Remove First: " + deque);
		deque.removeLast();
		System.out.println("Remove Last: " + deque);
	}

}
