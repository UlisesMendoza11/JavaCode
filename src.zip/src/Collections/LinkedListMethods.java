package Collections;

import java.util.LinkedList;

public class LinkedListMethods {

	public static void main(String[] args) {
		LinkedList<String> namesList = new LinkedList<String>();
		
		// add elements to the list
		namesList.add("Alice");
		namesList.add("Bob");
		namesList.add("Charlie");
		
		// print the list
		System.out.println("List: " + namesList);
		
		// add an element at the beginning of the list
		namesList.addFirst("David");
		
		// add an element at the end of the list
		namesList.addLast("Emily");
		
		// print the updated list
		System.out.println("List: " + namesList);
		
		// get the first element in the list
		String first = namesList.getFirst();
		System.out.println("First Element: " + first);
		
		// get the last element in the list
		String last = namesList.getLast();
		System.out.println("Last Element: " + last);
		
		// remove the first element in the list
		namesList.removeFirst();
		System.out.println("List: " + namesList);
		
		// remove the last element in the list
		namesList.removeLast();
		
		// print the updated list
		System.out.println("List: " + namesList);
	}

}
