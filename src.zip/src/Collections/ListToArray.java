package Collections;

import java.util.*;

public class ListToArray {

	public static void main(String[] args) {
		List<String> fruits = new ArrayList<>();
		
		fruits.add("Mango");
		fruits.add("Banana");
		fruits.add("Apple");
		fruits.add("Strawberry");
		
		String arr[] = fruits.toArray(new String[fruits.size()]);
		
		System.out.println("Printing Array: " + Arrays.toString(arr));
		System.out.println("Printing List: " + fruits);
	}

}
