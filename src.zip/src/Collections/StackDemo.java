package Collections;

public class StackDemo {

	public static void main(String[] args) {
		
	}

}
