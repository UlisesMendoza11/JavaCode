package Collections;
import java.util.*;
class Employee2 implements Comparable<Employee2>{
	
	int id, salary;
	String name, dept;
	
	Employee2(int id, String name, int salary, String dept) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.dept = dept;
	}
	
	public int compareTo(Employee2 e) {
		if(salary == e.salary) {
			return 0;
		} else if(salary > e.salary) {
			return 1;
		}
		return -1;
	}
	
}

public class EmployeeComparable {

	public static void main(String[] args) {
		Employee2 e1 = new Employee2(10001, "John", 4500, "Development");
		Employee2 e2 = new Employee2(10002, "Mary", 5000, "Testing");
		Employee2 e3 = new Employee2(10003, "Jane", 1000, "Maintenance");
		Employee2 e4 = new Employee2(10004, "Adam", 6000, "Design");
		
		ArrayList<Employee2> empList = new ArrayList<Employee2>();
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		
		Collections.sort(empList);
		
		for(Employee2 e : empList) {
			System.out.println(e.id + " " + e.name + " " + e.dept + " " + e.salary);
		}
	}

}
