package Collections;
import java.util.*;
class Book1 {
	int id, qty, price;
	String name;
	
	Book1(int id, String name, int qty, int price) {
		this.id = id;
		this.name = name;
		this.qty = qty;
		this.price = price;
	}
}

public class BookMap {

	public static void main(String[] args) {
		Book1 b1 = new Book1(1001, "Html", 15, 1500);
		Book1 b2 = new Book1(1002, "Java", 43, 2500);
		Book1 b3 = new Book1(1003, "CSS", 34, 4255);
		
		Map<Integer, Book1> bookMap = new HashMap<Integer, Book1>();
		bookMap.put(1, b1);
		bookMap.put(2, b2);
		bookMap.put(3, b3);
		
		for(Map.Entry<Integer, Book1>entry: bookMap.entrySet()) {
			int key = entry.getKey();
			Book1 b = entry.getValue();
			System.out.println(key + "Details");
			System.out.println(b.id + " " + b.name + " " + b.qty + " " + b.price);
		}
	}

}
