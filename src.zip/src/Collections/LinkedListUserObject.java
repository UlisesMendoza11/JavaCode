package Collections;
import java.util.*;

class Book {
	int id, quantity;
	String name, author;
	
	Book(int id, String name, String author, int quantity) {
		this.id = id;
		this.name = name;
		this.author = author;
		this.quantity = quantity;
	}
}


public class LinkedListUserObject {

	public static void main(String[] args) {
		List<Book> bookList = new LinkedList<Book>();
		
		Book b1 = new Book(111, "JAVA", "Bala Gurusamy", 200);
		Book b2 = new Book(112, "Web Technology", "Galvin", 300);
		Book b3 = new Book(113, "Spring Book", "Galvin", 400);
		
		bookList.add(b1); bookList.add(b2); bookList.add(b3);
		for(Book b: bookList) {
			System.out.println(b.id + " " + b.name + " " + b.author + " " + b.quantity);
		}
	}

}
