package Collections;
import java.util.*;
import java.io.*;
public class ArrayListSerialization {

	public static void main(String[] args) throws Exception {
		ArrayList a1 = new ArrayList<>();
		
		a1.add("Ravi"); a1.add("Vijay"); a1.add("Ajay");
		
		FileOutputStream fos = new FileOutputStream("");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(a1); fos.close(); oos.close();
		
		FileInputStream fin = new FileInputStream("");
		ObjectInputStream oin = new ObjectInputStream(fin);
		
		ArrayList list = (ArrayList)oin.readObject();
		System.out.println(list);
	}

}
