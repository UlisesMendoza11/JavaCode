package Collections;
import java.util.*;
public class ArrayToList {

	public static void main(String[] args) {
		String[] array = {"Java", "Python", "Php", "HTML", "CSS"};
		
		System.out.println("Printing Array: " + Arrays.toString(array));
		
		// convert array to list
		List<String> list = new ArrayList<String>();
		for(String s: array) {
			System.out.println(s);
		}
		
	}

}
