package Collections;
import java.util.*;

class Employee {
	int empNo, salary;
	String empName;
	
	Employee(int empNo, int salary, String empName) {
		this.empNo = empNo;
		this.salary = salary;
		this.empName = empName;
	}
}

public class ArrayListDemo {

	public static void main(String[] args) {
		List employees = new ArrayList<>();
		employees.add(10011);
		employees.add("John");
		employees.add("Developement");
		employees.add(35000.350);
		
		System.out.println(employees);
		System.out.println(); System.out.println();
		
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("Mango"); list.add("Apple"); list.add("Banana"); list.add("Grape");
		
		System.out.println(list);
		
		Iterator itr = list.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		
		Employee e1 = new Employee(10011, 35000, "John");
		Employee e2 = new Employee(10012, 32000, "Sahar");
		Employee e3 = new Employee(10013, 45000, "Rohan");
		
		ArrayList<Employee> empList = new ArrayList<Employee>();
		empList.add(e1); empList.add(e2); empList.add(e3);
		
		Iterator itr1 = empList.iterator();
		while(itr.hasNext()) {
			Employee eTemp = (Employee) itr1.next();
			System.out.println(eTemp.empNo + " " + eTemp.salary + " " + eTemp.empName);
		}
	}

}
