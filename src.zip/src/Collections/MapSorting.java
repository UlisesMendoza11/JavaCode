package Collections;
import java.util.*;

public class MapSorting {

	public static void main(String[] args) {
		Map map = new HashMap();
		
		map.put(103, "Vegetables");
		map.put(104, "Furniture");
		map.put(105, "Mobiles");
		map.put(105, "Electronics");
		map.put(101, "Books");
		map.put(102, "Fruits");
		map.putIfAbsent(108, "Note book");
		map.putIfAbsent(111, "Stationary");
		
		map.entrySet().stream().sorted(Map.Entry.comparingByKey())
		.forEach(System.out::println);
		System.out.println();
		map.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
		.forEach(System.out::println);
		
		Map map1 = new HashMap();
		
		map1.put(119, "10001");
		map1.put(120, "Laptop");
		map1.put(125, "105");
		map.putAll(map1);
		
		map.remove(101);
		System.out.println();
		System.out.println("After Remove:");
		
		map.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
		.forEach(System.out::println);
		
		System.out.println();
		map.replace(119, "10001", "Mouse");
		System.out.println("After Replace:");
		
		map.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
		.forEach(System.out::println);
	}

}
