package Collections;
import java.util.*;

public class LinkedHashMapDemo {

	public static void main(String[] args) {
		LinkedHashMap<String, String> emp = new LinkedHashMap<String, String>();
		
		emp.put("empId", "10011");
		emp.put("empName", "John");
		emp.put("dept", "Development");
		emp.put("salary", "$4500");
		
		for(Map.Entry e:emp.entrySet()) {
			System.out.println(e.getKey() + " ====> " + e.getValue());
		}
		
		System.out.println("Fetching keys");
		System.out.println("Keys: " + emp.keySet());
		
		System.out.println("Fetching values");
		System.out.println("Values: " + emp.values());
		
		System.out.println("Fetching key-pair");
		System.out.println("Key-Value pair: " + emp.entrySet());
		
		emp.remove("salary");
		System.out.println("After Remove");
		System.out.println("Key-Value pair: " + emp.entrySet());
		
	}

}
