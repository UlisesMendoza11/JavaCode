package Collections;
import java.util.*;

public class HashMapDemo {

	public static void main(String[] args) {
		Map map = new HashMap();
		
		map.put(101, "Books");
		map.put(102, "Fruits");
		map.put(103, "Vegetables");
		map.put(104, "Furniture");
		map.put(105, "Mobile");
		
		Set set = map.entrySet();
		Iterator itr = set.iterator();
		System.out.println("Key\tValue");
		
		while(itr.hasNext()) {
			Map.Entry entry  = (Map.Entry)itr.next();
			System.out.println(entry.getKey() + "\t" + entry.getValue());
		}
	}

}
