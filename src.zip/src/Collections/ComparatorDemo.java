package Collections;
import java.util.*;

class Person1 {
	
	int age;
	String name;
	
	Person1(String name, int age) {
		this.age = age;
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Person [name = " + name + ", age = " + age + "]";
	}
}

public class ComparatorDemo {

	public static void main(String[] args) {
		List<Person1> people = new ArrayList<>();
		
		people.add(new Person1("Alice", 25));
		people.add(new Person1("Bob", 30));
		people.add(new Person1("Charlie", 20));
		
		Comparator<Person1> byAge = new Comparator<Person1>() {
			@Override
			public int compare(Person1 p1, Person1 p2) {
				return p1.getAge() - p2.getAge();
			}
		};
		
		Collections.sort(people, byAge);
		
		System.out.println("People sorted by age in increasing order:");
		for(Person1 person : people) {
			System.out.println(person);
		}
		
		Comparator<Person1> byAgeReversed = (p1, p2) -> p2.getAge() - p1.getAge();
		Collections.sort(people, byAgeReversed);
		
		System.out.println("People sorted by age in decreasing order:");
		for(Person1 person : people) {
			System.out.println(person);
		}
		
	}

}
