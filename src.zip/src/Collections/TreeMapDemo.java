package Collections;

import java.util.*;

public class TreeMapDemo {

	public static void main(String[] args) {
		TreeMap<String, String> emp = new TreeMap<String, String>();
		
		emp.put("empId", "10011");
		emp.put("empName", "John");
		emp.put("dept", "Development");
		emp.put("salary", "$4500");
		emp.put("salary", "$4500");
		emp.put(null, null);
		
		for(Map.Entry e: emp.entrySet()) {
			System.out.println(e.getKey() + " ====> " + e.getValue());
		}
	}

}
