package Collections;
import java.util.*;
class Student implements Comparable<Student>
{
	int rollno, age;
	String name;
	
	Student(int rollno, String name, int age) {
		this.rollno = rollno;
		this.name = name;
		this.age = age;
	}
	
	public int compareTo(Student stu) {
		if(age == stu.age) {
			return 0;
		} else if(age > stu.age) {
			return 1;
		} else {
			return -1;
		}
	}
}

public class ComparableDemo {

	public static void main(String[] args) {
		ArrayList<Student> stu_obj = new ArrayList<Student>();
		
		Student s1 = new Student(111, "John", 22);
		Student s2 = new Student(222, "Mary", 25);
		Student s3 = new Student(333, "Adams", 27);
	}

}
