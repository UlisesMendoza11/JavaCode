package Collections;
import java.util.*;

public class HashTableDemo {

	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		
		hm.put(100, "James");
		hm.put(111, "Mary");
		hm.put(103, "David");
		hm.put(100, "Thomas");
//		hm.put(null, "James");	 cannot have null keys
		
		System.out.println(hm);
		
		for(Map.Entry e : hm.entrySet()) {
			System.out.println(e.getKey() + " ====> " + e.getValue());
		}
		
		hm.remove(103);
		
		System.out.println(hm);
		System.out.println(hm.getOrDefault(105, "Not Found"));
		System.out.println(hm.getOrDefault(200, "Not Found"));
		
		hm.putIfAbsent(200, "Jen");
		hm.putIfAbsent(100, "Lily");
		System.out.println(hm);
	}

}
