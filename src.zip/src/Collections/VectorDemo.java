package Collections;

public class VectorDemo {

	public static void main(String[] args) {
		
	}

}
