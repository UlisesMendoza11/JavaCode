package Collections;
import java.util.*;
public class HashSetDemo {

	public static void main(String[] args) {
		HashSet<String> set = new HashSet<String>();
		
		set.add("One");
		set.add("Two");
		set.add("Three");
		set.add("Four");
		set.add("Five");
		
		Iterator itr = set.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		HashSet<String> hashSet = new HashSet<String>();
		
		hashSet.add("John");
		hashSet.add("Andy");
		hashSet.add("Jennifer");
		hashSet.add("Sally");
		hashSet.add("Jessica");
		
		System.out.println("Initial Hash Set elements are: " + hashSet);
		
		hashSet.remove("Jennifer");
		System.out.println("After Remove: " + hashSet);
		
		HashSet<String> hs = new HashSet<String>();
		
		hs.add("Michael");
		hs.add("David");
		hashSet.addAll(hs);
		
		System.out.println("After addAll: " + hashSet);
	}

}
