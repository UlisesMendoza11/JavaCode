package Collections;

import java.util.*;

class Product {
	
	int pId;
	double price;
	String name;
	
	public String toString() {
		return "\n Product Id: " + pId + "\n Product Name: \"" + name + "\"\n Price: " + price;
	}
	
	Product(int pId, String name, double price) {
		this.pId = pId;
		this.name = name;
		this.price = price;
	}
}

public class ProductDemo {

	public static void main(String[] args) {
		ArrayList<Product> pList1 = new ArrayList<Product>();
		LinkedList<Product> pList2 = new LinkedList<Product>();
		
		Product p1 = new Product(1001, "Book", 11.99);
		Product p2 = new Product(1002, "Chair", 32.49);
		Product p3 = new Product(1003, "Table", 50.99);
		
		pList1.add(p1); pList1.add(p2); pList1.add(p3);
		pList2.add(p1); pList2.add(p2); pList2.add(p3);
		
		System.out.println("ArrayList of Products: " + pList1); System.out.println();
		System.out.println("LinkedList of Products: " + pList2); System.out.println();
		
		// getting data from lists
		System.out.println("Data from ArrayList: " + pList1.get(0));
		System.out.println("Data from LinkedList: " + pList2.getLast()); System.out.println();
		
		// removing data from lists
		pList1.remove(0);
		System.out.println("ArrayList of Products: " + pList1); System.out.println();
		pList2.removeFirst();
		System.out.println("LinkedList of Products: " + pList2); System.out.println();
		
		// adding more data to lists
		pList1.add(new Product(1004, "Cup", 4.99));
		pList2.addLast(new Product(1005, "Pot", 8.99));
		
		System.out.println("ArrayList of Products: " + pList1); System.out.println();
		System.out.println("LinkedList of Products: " + pList2); 
	}

}
