package Collections;
import java.util.*;
import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		// create a new linked list
		LinkedList<String> linkedList = new LinkedList<>();
		
		// add elements to the linked list
		linkedList.add("apple");
		linkedList.add("banana");
		linkedList.add("cherry");
		
		// print the contents of the linked list
		System.out.println("Linked Link: " + linkedList);
		
		// add an element at a specific index
		linkedList.add(1, "grape");
		
		// print the contents of the linked list again
		System.out.println("Linked List after adding grape: " + linkedList);
		
		// remove an element from the linked list
		linkedList.remove("banana");
		
		// print the contents of the linked list again
		System.out.println("Linked List after removing banana: " + linkedList);
		
		// get the element at a specific index
		String element = linkedList.get(2);
		System.out.println("Element at index 2: " + element);
		
		// check if the linked list contains an element
		boolean contains = linkedList.contains("cherry");
		System.out.println("Contains cherry? " + contains);
	}

}
