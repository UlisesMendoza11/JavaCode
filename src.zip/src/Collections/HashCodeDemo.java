package Collections;

import java.util.*;
class Person {
	
	private int id;
	private String name;
	private int age;
	
	Person(int id, String name, int age) {
		this.id = id;
		this.age = age;
		this.name = name;
	}
	
	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int hashCode() {
		return Objects.hash(id, name, age);
	}
	
	public boolean equals(Object obj) {
		if(this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		
		Person person = (Person)obj;
		return id == person.id && age == person.age && Objects.equals(name, person);
	}
}

public class HashCodeDemo {

	public static void main(String[] args) {
		List<Person> pList = new ArrayList<Person>();
		Person p1 = new Person(111, "Alice", 25);
		Person p2 = new Person(222, "Bob", 27);
		Person p3 = new Person(333, "Jacob", 29);
		
		int hashCode1 = p1.hashCode();
		int hashCode2 = p2.hashCode();
		int hashCode3 = p3.hashCode();
		
		System.out.println("Hash Code for p1: " + hashCode1);
		System.out.println("Hash Code for p2: " + hashCode2);
		System.out.println("Hash Code for p3: " + hashCode3);
		
		pList.add(p1); pList.add(p2); pList.add(p3);
		
		for(Person p : pList) {
			System.out.println(p.getId() + " " + p.getName() + " " + p.getAge());
		}
	}

}
