package Collections;
import java.util.*;
public class PriorityQueueDemo {

	public static void main(String[] args) {
		PriorityQueue queue = new PriorityQueue<>();
		
		queue.offer(89);
		queue.offer(54);
		queue.offer(45);
		queue.offer(43);
		queue.offer(76);
		
		System.out.println("Priority Queue: " + queue);
		
		System.out.println("First Element Priority Queue: " + queue.peek());
		System.out.println("Remove Element from Priority Queue:");
		
		while(!queue.isEmpty()) {
			System.out.println(queue.poll());
		}
		
		System.out.println("Priority Queue: " + queue);
	}

}
