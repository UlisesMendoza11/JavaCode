package Polymorphism;

class Animal 
{
	
	public void makeSound()
	{
		System.out.println("The animal makes a sound");
	}
}

class Dog extends Animal
{
	public void makeSound()
	{
		super.makeSound();
		System.out.println("The Dog barks");
	}
}

public class RuntimePolymorphism {

	public static void main(String[] args) {
		Dog d = new Dog();
		d.makeSound();
	}

}
