package Polymorphism;

class Parent
{
	public void show() {
		System.out.println("From parent class");
	}
	
	public int calculate(int x, int y) {
		return x+y;
	}
}

class Child extends Parent
{
	public void show() {
		super.show();
		System.out.println("From child class");
	}
	
	public int calculate(int x, int y) {
		System.out.println(super.calculate(5, 5));
		return x*y;
	}
}

public class Overriding {

	public static void main(String[] args) {
		Child c = new Child();
		c.show(); System.out.println(c.calculate(5,5));
	}

}
