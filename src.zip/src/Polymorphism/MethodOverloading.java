package Polymorphism;
import java.util.Scanner;
import java.util.Scanner;

class Shape {
	public void area()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the radius value: ");
		double r = sc.nextDouble();
		
		double area = 3.14*r*r;
		System.out.println("Area of the circle is: " + area);
		
		sc.close();
	}
	
	public void area(float s)
	{
		double area = s*s;
		System.out.println("Area of square is: " + area);
	}
	
	public void area(float l, float w, float area)
	{
		area = l*w;
		System.out.println("Area of rectangle is: " + area);
	}
}


public class MethodOverloading {

	public static void main(String[] args) {
		
	}

}
