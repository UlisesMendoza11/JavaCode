package JDK8_Features;

@FunctionalInterface
interface Drawable {
	void draw(String msg);
	
}

public class FunctionalInterfaceDemo implements Drawable {

	public void draw(String msg) {
		System.out.println("Functional Interface Demo..." + msg);
	}
	
	public static void main(String[] args) {
		FunctionalInterfaceDemo obj = new FunctionalInterfaceDemo();
		
		obj.draw("Draw abstract method from functional interface");
	}

}
