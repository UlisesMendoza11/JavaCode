package JDK8_Features;

@FunctionalInterface
interface Drawable1 {
	public void draw();
}

@FunctionalInterface
interface Sayable1 {
	public String say(String s);
}

@FunctionalInterface
interface Addable {
	public int add(int x, int y);
}

public class LambdaExpDemo {

	int calculate(int x, int y) {
		return x*y;
	}
	
	public static void main(String[] args) {
		int width = 15;
		
		Drawable1 obj = () -> { System.out.println("Drawing width: " + width); };
		
		obj.draw();
		
		Sayable1 s1 = (name) -> { return "Hello " + name;};
		System.out.println(s1.say("Peter"));
		Sayable1 s2 = (name) -> { return "Welcome " + name;};
		System.out.println(s1.say("Mary"));
		
		
		Addable a1 = (x,y) -> { return (x+y); };
		System.out.println(a1.add(54, 65));
	}

}
