package JDK8_Features;
import java.util.*;
import java.util.stream.Stream;

class Product {
	
	int id, price;
	String name;
	
	Product(int id, String name, int price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

public class LambdaFilter {

	public static void main(String[] args) {
		List<Product> pList = new ArrayList<Product>();
		
		pList.add(new Product(10011, "Books", 15000));
		pList.add(new Product(10022, "Table", 25000));
		pList.add(new Product(10033, "Chair", 18000));
		pList.add(new Product(10044, "Stationary", 12000));
		pList.add(new Product(10055, "Laptop", 55000));
		
		Stream<Product> filteredData = pList.stream().filter((p) -> p.price > 20000);
		
		filteredData.forEach(
					(p) -> System.out.println(p.id + " " + p.name + " " + p.price)
				);
		
		System.out.println("===================================");
		
		pList.forEach((e) -> System.out.println());
		
	}

}
