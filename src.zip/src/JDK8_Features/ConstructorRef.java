package JDK8_Features;

@FunctionalInterface
interface Messagable
{
	public Message msg(String msg);
}

class Message {
	
	Message(String msg) {
		System.out.println(msg);
	}
}

public class ConstructorRef {

	public static void main(String[] args) {
		Messagable mObj = Message::new;
		mObj.msg("Hello World");
	}

}
