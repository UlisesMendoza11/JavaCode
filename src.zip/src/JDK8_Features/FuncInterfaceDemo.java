package JDK8_Features;

interface Doable {
	default void doit() {
		System.out.println("Do it now");
	}
	
//	void demo();
}

@FunctionalInterface
interface Sayable extends Doable {
	void say(String msg);
}

public class FuncInterfaceDemo implements Doable {

	public void say(String msg) {
		System.out.println(msg);
	}
	
	public static void main(String[] args) {
		FuncInterfaceDemo f1 = new FuncInterfaceDemo();
		f1.say("Hello There");
		f1.doit();
	}

}
