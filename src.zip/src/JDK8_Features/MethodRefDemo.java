package JDK8_Features;

import java.util.function.BiFunction;

interface Sayable123 {
	
	void say();
}

@FunctionalInterface
interface Sayable3 {
	public void say();
}

class Arithmetic {
	public static int add(int a, int b) {
		return a+b;
	}
	
	public int addAgain(int a, int b) {
		return a+b;
	}
}

public class MethodRefDemo {
	
	public static void saySomething() {
		System.out.println("Hello this is static method");
	}
	
	public void saySome() {
		System.out.println("Hello this is non-static method");
	}

	public static void main(String[] args) {
		Sayable123 s = MethodRefDemo::saySomething;
		
		s.say();
		
		BiFunction<Integer, Integer, Integer> adder1 = Arithmetic::add;
		System.out.println(adder1.apply(34, 87));
		
		MethodRefDemo mRef = new MethodRefDemo();
		Sayable3 sayObj1 = mRef::saySome;
		sayObj1.say();
		
		Sayable3 sayObj2 = new MethodRefDemo() :: saySome;
		sayObj2.say();
		
		Arithmetic aObj = new Arithmetic();
		BiFunction<Integer, Integer, Integer> adder2 = aObj::addAgain;
		System.out.println(adder2.apply(34, 87));
	}

}
