package JDK8_Features;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Employee {
	
	int id;
	float salary;
	String name;
	
	 Employee(int id, String name, float salary) {
		 this.id = id;
		 this.name = name;
		 this.salary = salary;
	 }
}

public class EmployeeCollectionFilter {

	public static void main(String[] args) {
		List<Employee> empList = new ArrayList<Employee>(); 
		
		empList.add(new Employee(1, "Daniel", 25000f));
		empList.add(new Employee(2, "James", 30000f));
		empList.add(new Employee(3, "Harry", 78000f));
		empList.add(new Employee(4, "Mary", 58000f));
		empList.add(new Employee(5, "Jennifer", 90000f));
		
		List<Float> employeeSalaryList = empList.stream()
				.filter(e -> e.salary > 50000)
				.map(e -> e.salary)
				.collect(Collectors.toList());
		System.out.println(employeeSalaryList);
		
		employeeSalaryList.forEach((i) -> System.out.println(i));
	}

}
