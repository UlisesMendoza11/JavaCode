package ConditionalStatements;

import java.util.Scanner;

public class PizzaOrderingSystem {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		// prompt the user for their name and address
		System.out.println("Welcome to the pizza ordering system");
		System.out.print("Please enter your name: ");
		String name = sc.nextLine();
		System.out.print("Please enter your address: ");
		String address = sc.nextLine();
		
		// prompt the user for their pizza order
		System.out.println("Please select your pizza size:");
		System.out.println("1. Small ($10.00)");
		System.out.println("2. Medium ($12.00)");
		System.out.println("3. Large ($14.00)");
		System.out.print("Ener your choice (1-3)");
		int sizeChoice = sc.nextInt();
		
		// calculate the pizza price based on the selected size
		double pizzaPrice = 0.0;
		if (sizeChoice == 1) {
			pizzaPrice = 10.00;
		} else if (sizeChoice == 2) {
			pizzaPrice = 12.00;
		} else if (sizeChoice == 3) {
			pizzaPrice = 14.00;
		}
		
		// prompt the user for their toppings
		System.out.println("Please select your toppings (enter 'done' when finished):");
		System.out.println("1. Pepperoni ($1.00)");
		System.out.println("2. Mushrooms ($1.00)");
		System.out.println("3. Pepperoni ($1.00)");
		System.out.println("4. Sausage ($1.00)");
		System.out.println("5. Bacon ($1.50)");
		System.out.println("6. Extra ($1.50)");
		
		String toppings = "";
		double toppingsPrice = 0.0;
		boolean done = false;
		while(!done) {
			System.out.print("Enter your choice (1-6, or 'done'): ");
			String toppingChoice = sc.next();
			if(toppingChoice.equalsIgnoreCase("done")) {
				done = true;
			} else {
				int topping = Integer.parseInt(toppingChoice);
				if (topping == 1 | topping == 2 | topping == 3 | topping == 4) {
					toppings += " " + toppingChoice;
					toppingsPrice += 1.00;
				} else if (topping == 5 | topping == 6) {
					toppings += " " + toppingChoice;
					toppingsPrice += 1.50;
				}
			}
		}
		
		// calculate the total cost of the order
		double totalCost = pizzaPrice + toppingsPrice;
		// display the order summary to the user
		System.out.println("Thank you for your order, " + name + "!");
		System.out.println("Your pizza will be delivered to " + address + ".");
		System.out.println("Your order includes the following toppings: " + toppings);
		System.out.println("Your total cost is $" + totalCost + ".");
	}

}
