package ConditionalStatements;
import java.util.Scanner;
public class DoWhile {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String password;
		
		do {
			System.out.print("Enter the password: ");
			password = sc.nextLine();
		} while (!password.equals("abc123"));
		
		System.out.println("Access granted!...");
		
		sc.close();
	}

}
