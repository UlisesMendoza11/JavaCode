package ConditionalStatements;

import java.util.Scanner;

public class Marklist2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the number of students: ");
		int numStudents = sc.nextInt();
		
		for(int i = 1; i <= numStudents; i++) {
			System.out.println("Student#" + i);
			int regNo;
			String studentName;
			double score1, score2, score3, total, avg;
			
			System.out.print("Enter registration number: ");
			regNo = sc.nextInt();
			sc.nextLine();
			System.out.print("Enter the student name: ");
			studentName = sc.nextLine();
			System.out.print("Enter first test score: ");
			score1 = sc.nextDouble();
			System.out.print("Enter second test score: ");
			score2 = sc.nextDouble();
			System.out.print("Enter third test score: ");
			score3 = sc.nextDouble();
			total = score1+score2+score3;
			avg = total/3.0;
			char grade;
			if (avg >= 90.0) {
				grade = 'A';
			} else if (avg >= 80.0) {
				grade = 'B';
			} else if (avg >= 70.0) {
				grade = 'C';
			} else if (avg >= 60.0) {
				grade = 'D';
			} else {
				grade = 'F';
			}
			System.out.print("\n\n");
			System.out.println(studentName + "'s Marklist");
			System.out.println("Score1 = " + score1);
			System.out.println("Score2 = " + score2);
			System.out.println("Score3 = " + score3);
			System.out.println("Total Score = " + total);
			System.out.println("Average Score = " + avg);
			System.out.println("Grade " + grade + "\n");
		}
	}

}
