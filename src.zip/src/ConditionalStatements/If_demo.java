package ConditionalStatements;
import java.util.Scanner;

public class If_demo {

	public static void main(String[] args) {
		String cus_name, address;
		float billAmt;
		int tot_units, meterNo, price_per_unit;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Consumer Name: ");
		cus_name = sc.nextLine();
		System.out.println("Enter the Eb Name: ");
		meterNo = sc.nextInt(); sc.nextLine();
		System.out.println("Enter the Consumer Address: ");
		address = sc.nextLine();
		System.out.println("Enter the Total Units");
		tot_units = sc.nextInt();
		
		if (tot_units < 100) {
			price_per_unit = 12;
			System.out.println("per unit price is: " + price_per_unit);
			billAmt = price_per_unit*tot_units;
		} else if (tot_units > 100 && tot_units < 200) {
			price_per_unit = 12;
			System.out.println("per unit price is: " + price_per_unit);
			billAmt = price_per_unit*tot_units;
		} else {
			price_per_unit = 18;
			System.out.println("per unit price is: " + price_per_unit);
			billAmt = price_per_unit*tot_units;
		}
		
		System.out.println("EB Bill Receipt");
		System.out.println("Consumer Name: " + cus_name);
		System.out.println("Consumer Address: " + address);
		System.out.println("Eb Number: " + meterNo);
		System.out.println("Bill Amount: " + billAmt);
	}

}
