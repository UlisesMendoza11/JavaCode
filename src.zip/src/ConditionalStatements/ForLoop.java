package ConditionalStatements;
import java.util.Scanner;

public class ForLoop {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the price per unit: ");
		double price = sc.nextDouble();
		
		System.out.print("Enter the no of units sold: ");
		int quantity = sc.nextInt();
		
		
		double total = 0;
		
		for(int i = 1; i <= quantity; i++) {
			System.out.println("unit: " + i);
			total+=price;
		}
		System.out.print("Total Sales: $");
		System.out.printf("%.2f", total);
		
		sc.close();
	}

}
