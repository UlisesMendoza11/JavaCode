package ConditionalStatements;
import java.util.Scanner;
public class WhileLoop {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int randNumber = (int)(Math.random()*10) + 1;
		int guess;
		
		System.out.print("Guess number between 1 and 10: ");
		guess = sc.nextInt();
		
		while(guess != randNumber) {
			System.out.println("Incorrect guess, try again!");
			guess = sc.nextInt();
		}
		
		System.out.println("Correct, the number was: " + randNumber);
		sc.close();
	}

}
