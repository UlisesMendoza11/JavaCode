package ConditionalStatements;

public class DataTypeConversion {

	public static void main(String[] args) {
		
		int i = 10;
		double d = 3.14;
		char c = 'A';
		String s = "123";
		
		// widening or implicit conversion
		double result1 = i;
		int result2 = c;
		int result3 = Integer.parseInt(s);
		
		System.out.println("widening conversion");
		
		// narrowing or explicit conversion
		
		int result4 = (int) d;
		char result5 = (char) i;
		String result6 = String.valueOf(i);
		
		System.out.println("int to double: " + result1);
		System.out.println("char to int: " + result2);
		System.out.println("string to int: " + result3);
		System.out.println("narrowing conversion");
		System.out.println("double to int: " + result4);
		System.out.println("int to char: " + result5);
		System.out.println("int to string: " + result6);
	}
}
