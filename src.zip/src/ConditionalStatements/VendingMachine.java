package ConditionalStatements;
import java.util.Scanner;

/**
 * You are building a program to simulate a vending 
 * machine that dispenses drinks based on the user's 
 * selection and the amount of money they insert. Write 
 * a Java program that allows the user to enter the amount
 * of money they have and the number corresponding to the
 * drink they want to purchase. The program should then 
 * dispense the drink if the user has enough money and 
 * display an appropriate message if they do not. Assume 
 * that the vending machine has the following drinks and 
 * prices: Coke: $1.50 Pepsi: $1.75 Sprite: $1.25 
 *
 */
public class VendingMachine {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		float balance;
		boolean isItemNum = true;
		
		System.out.print("Enter your balance: ");
		// pass in balance of user
		balance = sc.nextFloat();
		System.out.print("Items:\n#1001 Coke: $1.50\n"
					+ "#1002 Pepsi: $1.75\n#1003 Sprite: "
					+ "$1.25\nEnter item number: ");
		do {
			
			// pass in the user's choice of item
			int item_num = sc.nextInt();
			// check case for each item number
			switch(item_num) {
				// Coke case
				case 1001:
					if(balance < 1.5) {
						System.out.println("Not enough balance! Try again later.");
						break;
					}
					System.out.print("Enjoy your Coke! Recurring balance: $");
					System.out.printf("%.2f", (balance-1.5));
					isItemNum = false;
					break;
				// Pepsi case
				case 1002:
					if(balance < 1.75) {
						System.out.println("Not enough balance! Try again later.");
						break;
					}
					System.out.print("Enjoy your Pepsi! Recurring balance: $");
					System.out.printf("%.2f", (balance-1.75));
					isItemNum = false;
					break;
				// Sprite case
				case 1003:
					if(balance < 1.25) {
						System.out.println("Not enough balance! Try again later.");
						break;
					}
					System.out.print("Enjoy your Sprite! Recurring balance: $");
					System.out.printf("%.2f", (balance-1.25));
					isItemNum = false;
					break;
				default:
					System.out.println("Item number not found. Try again.");
			}
		} while (isItemNum);
		sc.close();
	}

}
