package OOPs;

import java.util.Scanner;

public class VMS {

	static int[] stringToArr(String str, int length) {
		int[] array = new int[length];
		String temp = "";
		int array_index = 0;
		for(int i = 0; i < str.length(); i++) {
			// store character
			char tempChar = str.charAt(i);
			// if it is a space
			if (tempChar == ' ') {
				// store string that contains int to array
				array[array_index] = Integer.parseInt(temp);
				// reset temp string for next integer
				temp = "";
				// increment here so you dont get error
				array_index++;
				continue;
			}
			else if (i == str.length()-1) {
				temp += tempChar;
				array[array_index] = Integer.parseInt(temp);
				break;
			}
			else {
				// add digit to string
				temp += tempChar;
			}
		}
		
		return array;
	}
	
	static boolean contains(int[] arr, int num) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == num) {
				return true;
			}
		}
		
		return false;
	}
	
	static int trackedAndIgnored(int[] arr1, int[] arr2) {
		int count = 0;
		int[] smallest = arr1.length > arr2.length ? arr2 : arr1;
		int[] largest = arr1.length <= arr2.length ? arr2 : arr1;

		for (int i = 0; i < smallest.length; i++) {
			if (contains(largest, smallest[i])) {
				count++;
			}
		}
		return count;
	}
	
	static int untrackedAndUnignored(int[] arr1, int[] arr2, int totalFiles) {
		int count = arr1.length < arr2.length ? arr2.length : arr1.length;
		int[] smallest = arr1.length > arr2.length ? arr2 : arr1;
		int[] largest = arr1.length <= arr2.length ? arr2 : arr1;
		
		for (int i = 0; i < smallest.length; i++) {
			if (!contains(largest, smallest[i])) {
				count++;
			}
		}
		return totalFiles - count;
	}
	
	static void print(int[] arr) {
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int[] firstLine = stringToArr(sc.nextLine(), 3);
		int n = firstLine[0];
		int m = firstLine[1];
		int k = firstLine[2];
		
		int[] secondLine = stringToArr(sc.nextLine(), m);
		
		int[] thirdLine = stringToArr(sc.nextLine(), k);
		
		System.out.println("Number of Files: " + n);
		System.out.println("Number of Ignored Files: " + m);
		System.out.println("Number of Tracked Files: " + k);
		System.out.print("Ignored Files: "); print(secondLine);
		System.out.print("Tracked Files: "); print(thirdLine);
		
		System.out.println("Tracked and Ignored: " + trackedAndIgnored(secondLine, thirdLine));
		System.out.println("Untracked and Unignored: " + untrackedAndUnignored(secondLine, thirdLine, n));
		
		sc.close();
	}

}
