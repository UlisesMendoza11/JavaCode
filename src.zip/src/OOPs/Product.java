package OOPs;
import java.util.Scanner;
public class Product {

	int nos, price, tot;
	String name;
	Scanner sc = new Scanner(System.in);
	
	void getDetails()
	{
		System.out.println("Enter the Product Name:" );
		name = sc.nextLine();
		
		System.out.println("Enter the Product Price:" );
		price = sc.nextInt();
		
		System.out.println("Enter the No of Products:" );
		nos = sc.nextInt();
		
	}
	
	void calculate()
	{
		tot = nos*price;
	}
	
	void receipt()
	{
		System.out.println("Product Name: " + name);
		System.out.println("Product Price: " + price);
		System.out.println("No of Products: " + nos);
		System.out.println("Total Bill Amount: " + tot);
	}
	
	public static void main(String[] args) {
		Product p = new Product();
		
		p.getClass(); p.calculate(); p.receipt();
	}

}
