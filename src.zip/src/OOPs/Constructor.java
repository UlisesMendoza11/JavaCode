package OOPs;


class ProductClass
{
	String name;
	int id, price;
	
	ProductClass(String name, int id, int price)
	{
		this.name = name;
		this.id = id;
		this.price = price;
	}
	
	void show()
	{
		System.out.println("Name: " + name + " Id: " + id + " Price: " + price);
	}
}

class Demo
{
	String name, dept;
	int id;
	
	Demo(String name, String dept, int id)
	{
		this.name = name;
		this.dept = dept;
		this.id = id;
	}
	
	void show()
	{
		System.out.println("Name: " + name + " Id: " + id + " Department: " + dept);
	}
}

public class Constructor {
	
	public static void main(String[] args) {
		Demo d = new Demo("Sachin", "Development", 10011);
		d.show();
		Demo d1 = new Demo("John", "Development", 10012); d1.show();
		Demo d2 = new Demo("Shyam", "Development", 10033); d2.show();
		
		ProductClass p1 = new ProductClass("Chair", 10001, 10); p1.show();
		ProductClass p2 = new ProductClass("Table", 10002, 40); p2.show();
		ProductClass p3 = new ProductClass("Tv", 10003, 100); p3.show();
	}
}
