package OOPs;
import java.util.Scanner;
public class Test {

	static int[] stringToArr(String str, int length) {
		int[] array = new int[length];
		String temp = "";
		int array_index = 0;
		for(int i = 0; i < str.length(); i++) {
			// store character
			char tempChar = str.charAt(i);
			// if it is a space
			if (tempChar == ' ') {
				// store string that contains int to array
				array[array_index] = Integer.parseInt(temp);
				// reset temp string for next integer
				temp = "";
				// increment here so you dont get error
				array_index++;
				continue;
			}
			else if (i == str.length()-1) {
				temp += tempChar;
				array[array_index] = Integer.parseInt(temp);
				break;
			}
			else {
				// add digit to string
				temp += tempChar;
			}
		}
		
		return array;
	}
	
	static void print(int[] arr) {
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}
	
	static int largest(int[] array) {
		int blueNum = 0, redNum = 0, greenNum = 0;
		for (int i = 0; i < array.length; i++) {
			switch(array[i]) {
				case 1:
					redNum++;
					break;
				case 2:
					greenNum++;
					break;
				case 3:
					blueNum++;
					break;
				default:
			}
		}
		int largest = (redNum < greenNum ? greenNum : redNum);
		return (largest < blueNum ? blueNum : largest);
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numRooms = sc.nextInt(); sc.nextLine();
		
		int[] array = stringToArr(sc.nextLine(), numRooms);
		
		System.out.println();
		
		System.out.print("Classroom Colors: "); print(array);
		
		System.out.print("Minimum Num of Rooms to Paint: " + (numRooms - largest(array)));
		
		sc.close();
	}

}
