package OOPs;

class Demo1
{
	String name;
	int id;
	float weight, height;
	boolean eligibleForLogin;
	
	Demo1(String name, int id, float height, float weight, boolean eligibility)
	{
		this.name = name;
		this.id = id;
		this.height = height;
		this.weight = weight;
		eligibleForLogin = eligibility;
	}
	
	Demo1(String name, int id, float height)
	{
		this.name = name;
		this.id = id;
		this.height = height;
	}
	
	void show()
	{
		System.out.println("Id: " + id);
		System.out.println("Name: " + name);
		System.out.println("Height: " + height);
		System.out.println("Weight: " + weight);
		System.out.println("Eligible: " + eligibleForLogin);
	}
}


public class DefaultConstructor {

	public static void main(String[] args) {
		Demo1 d = new Demo1("Joye1", 10033, 55.9f, 50.8f, true);
		d.show();
		Demo1 d1 = new Demo1("Roey", 10035, 50.25f);
		d1.show();
	}

}
