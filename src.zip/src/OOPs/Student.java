package OOPs;

public class Student {

	private String name;
	private int id;
	private double gpa;
	
	public Student(String name, int id, double gpa) {
		this.name = name;
		this.id = id;
		this.gpa = gpa;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getId() {
		return this.id;
	}
	
	public double getGpa() {
		return this.gpa;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	
	public static void main(String[] args) {
//		Student s1 = new Student();
		System.out.println("Name: ");
		System.out.println("Id: ");
		System.out.println("Gpa: ");
	}

}
