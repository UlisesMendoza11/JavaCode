package OOPs;
import java.util.Scanner;

public class AdjacentGame {
	
	static int[] stringToArr(String str, int length) {
		int[] array = new int[length];
		String temp = "";
		int array_index = 0;
		for(int i = 0; i < str.length(); i++) {
			// store character
			char tempChar = str.charAt(i);
			// if it is a space
			if (tempChar == ' ') {
				// store string that contains int to array
				array[array_index] = Integer.parseInt(temp);
				// reset temp string for next integer
				temp = "";
				// increment here so you dont get error
				array_index++;
				continue;
			}
			else if (i == str.length()-1) {
				temp += tempChar;
				array[array_index] = Integer.parseInt(temp);
				break;
			}
			else {
				// add digit to string
				temp += tempChar;
			}
		}
		
		return array;
	}
	
	static int largest(int[] array) {
		int largest = -1;
		for(int i = 0; i < array.length; i++) {
			int temp = array[i];
			if (largest < temp) {
				largest = temp;
			}
		}
		
		return largest;
	}
	
	static void print(int[] arr) {
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		// first line is N = num of sticks (max is 50 and always even)
		// next line is the length of each stick
		
		Scanner sc = new Scanner(System.in);
		int arrLen = sc.nextInt(); sc.nextLine();
		
		int[] array = stringToArr(sc.nextLine(), arrLen);
		
		System.out.println();
		
		System.out.println("Array: "); print(array);
		
		System.out.println("Largest: " + largest(array));
		
		sc.close();
	}

}
