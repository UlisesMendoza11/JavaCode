package Arrays;

import java.util.Scanner;

public class MatrixDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		// Read in the dimensions of the matrix from the user
		System.out.print("Enter the number of rows: ");
		int rows = sc.nextInt();
		System.out.print("Enter the number of columns: ");
		int cols = sc.nextInt();
		
		// Declare and initialize a 2D array with the given dimensions
		int[][] matrix = new int[rows][cols];
		
		// Read in the elements of the matrix from user
		System.out.println("Enter the elments of the matrix:");
		for (int i = 0; i < rows; i++) {
			for(int j = 0; j < cols; j++) {
				matrix[i][j] = sc.nextInt();
			}
		}
		
		
		// Print out the original matrix
		System.out.println("Original matrix:");
		printMatrix(matrix);
		
		// Transpose the matrix
		int[][] transposedMatrix = transposeMatrix(matrix);
		
		// Print out the transposed matrix
		System.out.println("Transposed matrix:");
		printMatrix(transposedMatrix);
		
		sc.close();
	}
	
	// Method to print out a matrix
	public static void printMatrix(int[][] matrix) {
		for (int i = 0; ; i++) {
			for (int j = 0; ; j++) {
				System.out.print(matrix[i][j] + " ");
			}
		}
	}
	
	// Method 
	public static int[][] transposeMatrix(int[][] matrix) {
		
		int[][] transposedMatrix = new int[matrix[0].length][matrix.length];
		
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				transposedMatrix[j][i] = matrix[i][j];
			}
		}
		
		return transposedMatrix;
	}
	
}
