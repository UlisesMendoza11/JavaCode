package Arrays;
import java.util.Scanner;
public class Matrix {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Row size");
		int r = sc.nextInt();
		
		System.out.println("Enter the Column size");
		int c = sc.nextInt();
		
		int table[][] = new int[r][c];
		
		System.out.println("Enter the table data: ");
		
		for(int i = 0; i < r; i++) {
			for(int j = 0; j < c; j++) {
				table[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("");
		
		for(int i = 0; i < r; i++) {
			for(int j = 0; j < c; j++) {
				System.out.println(table[i][j]);
			}
			System.out.println();
		}
	}

}
