package Arrays;
import java.util.Scanner;
public class EmpArray {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the number of employees: ");
		int nos = sc.nextInt();
		
		int empId[] = new int[nos];
		
		for(int i = 0; i < nos; i++) {
			System.out.print("Enter Employee " + (i+1) + " Id: ");
			empId[i] = sc.nextInt();
		}
		
		System.out.println("Employee Ids are: ");
		for(int i = 0; i < empId.length; i++) {
			System.out.println(i + " element: " + empId[i]);
		}
	}

}
