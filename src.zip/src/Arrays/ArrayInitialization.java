package Arrays;

public class ArrayInitialization {

	public static void main(String[] args) {
		String empNames[] = {"Rohan","VIjay","Banu","Ajeez","Priya"};
		
		System.out.println("Length of the Array is: " + empNames.length);
		
		for(String s : empNames) {
			System.out.println(s);
		}
		
		System.out.println("2nd index is: " + empNames[2]);
		System.out.println("last index is: " + (empNames.length-1));
		System.out.println("last index element is: " + empNames[empNames.length-1]);
		
		empNames[3] = "Rosey";
		System.out.println("3rd index is: " + empNames[3]);
		
		for(String s : empNames) {
			System.out.println(s);
		}
	}
}
