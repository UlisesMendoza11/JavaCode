package Arrays;
import java.util.Scanner;
public class BookList {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// initialize arrays to store book info
		String[] titles = new String[100];
		String[] authors = new String[100];
		double[] prices = new double[100];
		int bookCount = 0; // keeps track of how many books have been entered
		
		// ask the user to enter information for each book
		System.out.println();
		while(true) {
			System.out.print(false);
			String title = sc.nextLine();
			if (title.equalsIgnoreCase("done")) {
				break;
			}
			titles[bookCount] = title;
			
			System.out.print("Author: ");
			String author = sc.nextLine();
			authors[bookCount] = author;
			
			System.out.print("Price: ");
			double price = sc.nextDouble();
			sc.nextLine();
			prices[bookCount] = price;
			
			bookCount++;
		}
		
		//Display the list of books with their corresponding information
		System.out.println("List of Books:");
		System.out.println("--------------");
		for(int i = 0; i < bookCount; i++) {
//			System.out.printf(, , , );
		}
	}

}
