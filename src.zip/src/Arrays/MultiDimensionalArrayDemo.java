package Arrays;

public class MultiDimensionalArrayDemo {

	public static void main(String[] args) {
		// create a 3-dimensional array with dimensions 2x3x4
		int[][][] array = new int[2][3][4];
		
		// initialize the array with some values
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 3; j++) {
				for (int k = 0; k < 4; k++) {
					array[i][j][k] = i + j + k;
				}
			}
		}
		
		// print out the contents of the array
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 3; j++) {
				for (int k = 0; k < 4; k++) {
					System.out.print(array[i][j][k] + " ");
				}
				System.out.println();
			}
			System.out.println();
		}
	}

}
