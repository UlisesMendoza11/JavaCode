package Arrays;
import java.util.Scanner;
public class RetailStore {

	public static void main(String[] args) {
		String[] products = {"Product1", "Product2", "Product3", "Product4", "Product5", 
				"Product6", "Product7", "Product8", "Product9", "Product10"};
		double[] prices = {1.99, 3.49, 2.99, 4.99, 5.99, 7.49, 6.99, 2.49, 4.49, 8.99};
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a product name: ");
		String productName = sc.nextLine();
		
		for(int i = 0; ; i++) {
			if (products[i].equals(productName)) {
				System.out.println("The price of " + productName
						+ "is $" + prices[i]);
				break;
			}
		}
		
	}

}
