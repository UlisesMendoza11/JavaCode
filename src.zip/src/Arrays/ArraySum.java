package Arrays;
import java.util.Scanner;
public class ArraySum {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int[] numbers;
		int num, sum = 0;
		
		System.out.print("Enter the number of elements to be entered: ");
		num = sc.nextInt();
		
		numbers = new int[num];
		
		System.out.println("Enter " + num + " elements: ");
		
		for(int i = 0; i < num; i++) {
			numbers[i] = sc.nextInt();
			sum += numbers[i];
		}
		
		System.out.println("SUm of the lements entered is: " + sum);
	}

}
