package Arrays;
import java.util.Scanner;
public class StudentGrades {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the number of students: ");
		int numOfStudents = sc.nextInt();
		
		double[] grades = new double[numOfStudents];

		for(int i = 0; i < numOfStudents; i++) {
			System.out.print("Enter the grade for student " + (i+1) + ": ");
			grades[i] = sc.nextInt();
		}
		double sum = 0;
		
		for (double grade : grades) {
				sum += grade;
		}
		
		double average = sum / numOfStudents;
		
		System.out.println("The average grade for the class is " + average);
	}

}
