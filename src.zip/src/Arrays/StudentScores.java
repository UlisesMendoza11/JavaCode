package Arrays;

import java.util.Scanner;

public class StudentScores {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		// prompt user for number of students and subjects
		System.out.print("Enter the number of students: ");
		int numStudents = sc.nextInt();
		System.out.print("Enter the number of subjects: ");
		int numSubjects = sc.nextInt();
		
		// create multi dimensional array to hold scores
		int[][] scores = new int[numStudents][numSubjects];
		
		// prompt user to enter scores for each student and subject
		for (int i = 0; i< numStudents; i++) {
			System.out.println("Enter scores for student " + (i+1) + ":");
			for (int j = 0; j < numSubjects; j++) {
				System.out.println("Subject " + (j+1) + ":");
				scores[i][j] = sc.nextInt();
			}
		}
		
		// print out the scores for each student and subject
		for (int i = 0; i< numStudents; i++) {
			System.out.println("Student " + (i+1) + ":");
			for (int j = 0; j < numSubjects; j++) {
				System.out.println("Subject " + (j+1) + ": " + scores[i][j]);
			}
		}
	}

}
