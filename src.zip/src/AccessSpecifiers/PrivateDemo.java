package AccessSpecifiers;

public class PrivateDemo {

	protected String cus_Address = "Chicago";
	protected long acc_Number = 42710;
	
	void display()
	{
		System.out.println("Address: " + cus_Address);
		System.out.println("Account Number: " + acc_Number);
	}
	
	public static void main(String[] args) {
		
	}

}
