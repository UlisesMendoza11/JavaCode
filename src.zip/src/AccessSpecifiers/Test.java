package AccessSpecifiers;

public class Test extends PrivateDemo {

	public static void main(String[] args) {
		Test privateDemo = new Test();
		
		System.out.println("Address: " + privateDemo.cus_Address);
		System.out.println("Account Number: " + privateDemo.acc_Number);

		privateDemo.display();
	}

}
